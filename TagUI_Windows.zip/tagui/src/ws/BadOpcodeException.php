<?php

namespace WebSocket;
class BadOpcodeException extends Exception {}

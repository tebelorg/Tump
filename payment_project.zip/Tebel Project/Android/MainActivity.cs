﻿using System;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Media;
using Xamarin.Forms.Platform.Android;
//using Android.Hardware;

namespace Tebel.Android
{
	[Activity (
		Label = "   tebel",
		Icon = "@drawable/icon",
		MainLauncher = true,
		Theme = "@style/Theme.Splash",
		LaunchMode = LaunchMode.SingleInstance,
		ScreenOrientation = ScreenOrientation.Portrait,
		ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]

	public class MainActivity : FormsApplicationActivity
	{
	
	
	//public class MainActivity : FormsApplicationActivity, ISensorEventListener
	//{
		/*
		public SensorManager _sensorManager;
		public static float AndroidOrientationX;
		public static float AndroidOrientationY;
		public static float AndroidOrientationZ;
		object _syncLock = new object();
    	*/

		protected override void OnCreate (Bundle bundle)
		{

			// Revert theme and window features from the interstitial zygote.
			base.Window.RequestFeature(WindowFeatures.ActionBar);
			base.SetTheme(global::Android.Resource.Style.ThemeHoloLightDarkActionBar);

			base.OnCreate (bundle);

			//_sensorManager = (SensorManager) GetSystemService(Context.SensorService);
		    Xamarin.Forms.Forms.Init (this, bundle);
			LoadApplication (new App());
		}

		/*
		protected override void OnResume()
		{
			base.OnResume();
			_sensorManager.RegisterListener(this, _sensorManager.GetDefaultSensor(SensorType.Accelerometer), SensorDelay.Ui);
		}

		protected override void OnPause()
		{
			base.OnPause();
			_sensorManager.UnregisterListener(this);
		}

		public void OnAccuracyChanged(Sensor sensor, SensorStatus accuracy)
		{
			// We don't want to do anything here.
		}

		public void OnSensorChanged(SensorEvent e)
		{
			lock (_syncLock)
			{
				//AndroidOrientationX = (AndroidOrientationX + e.Values[0])/2;
				//AndroidOrientationY = (AndroidOrientationY + e.Values[1])/2 ;
				//AndroidOrientationZ = (AndroidOrientationZ + e.Values[2])/2 ;
				AndroidOrientationY = e.Values[1];

			}
		}
		*/

	}
}


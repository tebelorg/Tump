Devic Info Readme
Find the most up to date information at: https://github.com/jamesmontemagno/Xamarin.Plugins

**IMPORTANT**


Windows Phone:
Permissions to add:
ID_CAP_IDENTITY_DEVICE
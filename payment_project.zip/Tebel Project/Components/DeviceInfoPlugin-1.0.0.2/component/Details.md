# Device Info Plugin Details

Receive information about the device that you are using from a cross-platform API for Xamarin.iOS, Xamarin.Android, Windows Phone, and Windows

### Features
* Model
* Operating System
* Version
* Id
* Generate a unique Id for your application based off of these properties.

Works completely from shared code or PCL projects.
Card.io is a library for iOS and Android that can scan credit card details in from the device's camera similar to a barcode scanner.  Card.io makes scanning and entering Credit Card information simple.

## Features
 
 - **Live Camera Card Scanning** - Quick and simple integration.  Get up and running in 5 minutes.
 - **Optional Manual Entry** - Users can choose to type their credit cards in.  Card.io provides a slick interface for manual card entry.
 - **Secure** - No credit card information is stored or transmitted.
 - **Free** - SDK's are free for both Android and iOS.
 

## Learn More
Learn more about Card.io by visiting http://www.card.io
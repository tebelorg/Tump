# Vibrate Plugin Details


Simple but elegant way of performing Vibrate in your Xamarin.iOS, Xamarin.Android, PCL, Windows, and Xamarin.Forms projects.

Works completely from shared code or PCL projects.
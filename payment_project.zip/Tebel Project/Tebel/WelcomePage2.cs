﻿using System;
using Xamarin.Forms;

namespace Tebel
{ 
    class WelcomePage2 : ContentPage
	{

		public WelcomePage2()
        {
			this.Title = "Welcome2";
			this.BackgroundColor = Color.White;
			this.BackgroundImage = "restaurant.jpg";
			this.Padding = new Thickness(0, 0, 0, 0);

			Image WelcomeImage2 = new Image
			{
				Source = ImageSource.FromFile("Welcome2.png"),
				//WidthRequest = Device.OnPlatform(160,192,160),
				//HeightRequest = Device.OnPlatform(160,192,160),
				//WidthRequest = ParentView.Width,
				Opacity = 0.9,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};
		
			Image QuickGuideImage = new Image
			{
				Source = ImageSource.FromFile("quickguide.png"),
				Opacity = 0.9,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.FillAndExpand
			};

			this.Content = new StackLayout {
				Children = {
					WelcomeImage2,
					QuickGuideImage
				}
			};

		
		}
    }
}

﻿using Xamarin.Forms;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

using System.IO;
using SQLite;
using System.Net;
using System.Text;

#if __ANDROID__
//using Android.Media;
#endif

#if __IOS__
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.AudioToolbox;
using MonoTouch.AVFoundation;
//using BigTed;
//using System.Threading;
//using System.Drawing;
#endif

namespace Tebel
{

    class PayPage : ContentPage
    {

		public Task AnimateHelpText = null;


		Xamarin.Forms.Image WelcomeImage1 = new Xamarin.Forms.Image
		{
			Source = ImageSource.FromFile("WelcomeNew1.png"),
			Opacity = 1,
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Xamarin.Forms.Image WelcomeImage2 = new Xamarin.Forms.Image
		{
			Source = ImageSource.FromFile("WelcomeNew2.png"),
			Opacity = 0,
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};


		Xamarin.Forms.Image WelcomeImage3 = new Xamarin.Forms.Image
		{
			Source = ImageSource.FromFile("WelcomeNew3.png"),
			Opacity = 0,
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};
				
		//public bool MerchantMode = true;
		public bool PaymentInitiated = false;
		public Task AnimateScanningImage = null; 
		public Task UpdateMerchantStatus = null; 
		public Task GetMerchantStatus = null;
		public double PaymentAmount = 0;
		public static int SampleSize = 44100;
		public string MerchantStatus;

		Xamarin.Forms.Image RewardsImage = new Xamarin.Forms.Image
		{
			Source = ImageSource.FromFile("rewards.png"),
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.End,
			WidthRequest = Device.OnPlatform(50,50,50),
		};

		Xamarin.Forms.Image ScanningImage = new Xamarin.Forms.Image
		{
			Source = ImageSource.FromFile("RadarWaves.png"),
			WidthRequest = Device.OnPlatform(300,270,250),
//			WidthRequest = Device.OnPlatform(150,135,125),
			//HeightRequest = Device.OnPlatform(400,320,250),
			Opacity = 0.15,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Start,
			//HorizontalOptions = LayoutOptions.FillAndExpand,
			//VerticalOptions = LayoutOptions.FillAndExpand
		};
	 
	    Button RecordAudioButton = new Button {
			Text = "Record / Morse Code",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.FromRgb (0, 112, 192),
			WidthRequest = 320,
			HeightRequest = 60,
			BorderWidth = 1,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Dictionary <char, String> MorseCode = new Dictionary<char, String>()
		{
			// at 10ms per period and 44100 samples per second
			// character limit is 7 characters per transmission
			// A99.99Z --> maximum is 99.99 per transaction
			// shorter periods are needed to send more data

			{'1' , ".-"},
			{'2' , "-.."},
			{'3' , ".-."},
			{'4' , "--."},
			{'5' , ".."},
			{'6' , "-.-"},
			{'7' , "--"},
			{'8' , "-."},
			{'9' , "...-"},
			{'0' , "."},
			{'.' , "..."},
			{'M' , "-"},
			{'U' , "..-"},
			{'A' , ".--"},
			{'Z' , "...."}
		};    

		public Label PayLabel = new Label {
			Text = "     ready for payment",
			FontSize = 50,
			TextColor = Color.Black,//Color.FromRgb (64, 64, 64), // Color.Black, //Color.Black,//Color.Gray,
			//FontAttributes = FontAttributes.Bold,
			Opacity = 0,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Start,
		};

		public Label PlaceHolderLabel = new Label {
			Text = " ",
			FontSize = 18,
			TextColor = Color.Gray,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start,
		};

		/*
		public Button TestButton50 = new Button {
			Text = "+50",
			FontSize = 24,
			IsEnabled = true,
			FontAttributes = FontAttributes.Bold,
			TextColor = Color.White,
			BackgroundColor = Color.Gray,
			BorderWidth = 1,
			BorderColor = Color.Silver,
			HeightRequest = 80,
			WidthRequest = 80,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		public Button TestButton150 = new Button {
			Text = "+150",
			FontSize = 24,
			IsEnabled = true,
			FontAttributes = FontAttributes.Bold,
			TextColor = Color.White,
			BackgroundColor = Color.Gray,
			BorderWidth = 1,
			BorderColor = Color.Silver,
			HeightRequest = 80,
			WidthRequest = 80,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		public Button TestButton300 = new Button {
			Text = "+300",
			FontSize = 24,
			IsEnabled = true,
			FontAttributes = FontAttributes.Bold,
			TextColor = Color.White,
			BackgroundColor = Color.Gray,
			BorderWidth = 1,
			BorderColor = Color.Silver,
			HeightRequest = 80,
			WidthRequest = 80,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		*/

		public Button TestButtonBill = new Button {
			Text = "Bill",
			FontSize = 36,
			IsEnabled = true,
			FontAttributes = FontAttributes.Bold,
			TextColor = Color.White,
			BackgroundColor = Color.FromRgb(0,112,192),
			Opacity = 0.8,
			BorderWidth = 1,
			BorderColor = Color.Silver,
			HeightRequest = 110,
			WidthRequest = 110,
			BorderRadius = 55,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};


		Button ModeButton7 = new Button {
			Text = "Maybank Amex - free drink",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.Silver,
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 0.0,
			IsEnabled = false,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Button ModeButton6 = new Button {
			Text = "UOB Visa - 15% off",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.Silver,
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 0.0,
			IsEnabled = false,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Button ModeButton5 = new Button {
			Text = "EZ-Link Card",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.Silver,
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 0.0,
			IsEnabled = false,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Button ModeButton4 = new Button {
			Text = "POSB Savings",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.FromRgb (0, 112, 192),
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 0.0,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Button ModeButton3 = new Button {
			Text = "OCBC Visa - free gift",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.FromRgb (0, 112, 192),
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 0.0,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Button ModeButton2 = new Button {
			Text = "Stanchart Master - 5% off",
			FontSize = 18,
			BackgroundColor = Color.White,
			TextColor = Color.FromRgb (0, 112, 192),
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 0.0,
			BorderColor = Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		Button ModeButton1 = new Button {
			Text = "Citibank Visa - 10% off",
			FontSize = 18,
			TextColor = Color.White,
			FontAttributes = FontAttributes.Bold,
			BackgroundColor = Color.FromRgb(51,181,229),//Color.FromRgb(2,206,194),//Color.FromRgb(250,150,50),
			WidthRequest = Device.OnPlatform (300, 320, 320),
			HeightRequest = 60,
			BorderWidth = 1,
			Opacity = 1,
			BorderColor = Color.FromRgb(51,181,229),//Color.Silver,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};
			

		public PayPage()
        {
			//this.BackgroundImage = "sky.png";

			Title = "Pay";
			this.BackgroundColor = Color.White;
			//this.BackgroundColor = Color.FromRgb(64,64,64);
			this.Padding = new Thickness(0, 0, 0, 0);
			//this.Padding = new Thickness(10, 0, 10, 0);

			BoxView LineSeparator = new BoxView {
				Color =  Color.FromRgb (51, 181, 229),
				HeightRequest = 2,
				Opacity = 0,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center
			};

		    Button TestButton1 = new Button {
				Text = "1",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				Opacity = 0.8,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton2 = new Button {
				Text = "2",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton3 = new Button {
				Text = "3",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton4 = new Button {
				Text = "4",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton5 = new Button {
				Text = "5",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton6 = new Button {
				Text = "6",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton7 = new Button {
				Text = "7",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton8 = new Button {
				Text = "8",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton9 = new Button {
				Text = "9",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButton0 = new Button {
				Text = "0",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			/*
			Button TestButtonDot = new Button {
				Text = ".",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 80,
				WidthRequest = 80,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
			*/

			/*
			Button TestButtonA = new Button {
				Text = "A",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 80,
				WidthRequest = 80,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButtonZ = new Button {
				Text = "Z",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 80,
				WidthRequest = 80,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			Button TestButtonM = new Button {
				Text = "M",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 80,
				WidthRequest = 80,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};


			Button TestButtonU = new Button {
				Text = "U",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 80,
				WidthRequest = 80,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			*/

			Button TestButtonDel = new Button {
				Text = "<",
				FontSize = 50,
				IsEnabled = true,
				TextColor = Color.Gray,
				BackgroundColor = Color.White,
				Opacity = 0.8,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HeightRequest = 110,
				WidthRequest = 110,
				BorderRadius = 55,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
				

			/*
			Label PayAmount = new Label {
				Text = "S$",
				FontSize = 18,
				TextColor = Color.Gray,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};
			*/

			StackLayout ButtonsSet0 = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions = LayoutOptions.Center,
				Spacing = 0,
				Children = {
					TestButtonDel,
					TestButton0,
					//TestButtonDot,
					TestButtonBill
				}
			};

			StackLayout ButtonsSet1 = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions = LayoutOptions.Center,
				Spacing = 0,
				Children = {
					TestButton1,
					TestButton2,
					TestButton3
					//TestButton50
				}

			};

			StackLayout ButtonsSet2 = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions = LayoutOptions.Center,
				Spacing = 0,
				Children = {
					TestButton4,
					TestButton5,
					TestButton6
					//TestButton150
				}
			};

			StackLayout ButtonsSet3 = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions = LayoutOptions.Center,
				Spacing = 0,
				Children = {
					TestButton7,
					TestButton8,
					TestButton9
					//TestButton300
				}
			};

			/*
			StackLayout ButtonsSet4 = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions = LayoutOptions.Center,
				Spacing = 0,
				Children = {
					TestButtonA,
					TestButtonZ,
					TestButtonM,
					TestButtonU,
				}
			};
			*/



			if (!App.MerchantMode)
			{
				PayLabel.FontSize = 18;
				this.Content =
					new StackLayout {
					Spacing = Device.OnPlatform (10, 25, 10),
					Children = {
						PayLabel,
						LineSeparator,

						#if __ANDROID__
							PlaceHolderLabel,
							PlaceHolderLabel,
						#endif

						ScanningImage,

						#if __IOS__
							PlaceHolderLabel,
							PlaceHolderLabel,
							PlaceHolderLabel,
						#endif

						WelcomeImage1,
						WelcomeImage2,
						WelcomeImage3,
						ModeButton7,
						ModeButton6,
						ModeButton5,
						ModeButton4,
						ModeButton3,
						ModeButton2,
						ModeButton1


						//PlaceHolderLabel,
						//RecordAudioButton,
						//RewardsImage
					}
				};

				AnimateScanningImage = AsyncAnimateScanningImage ();
				AnimateScanningImage = AsyncRotateScanningImage ();

				//AnimateScanningImage = UpdatePhoneOrientation ();


				if (Device.OnPlatform (1, 2, 3) == 1) {
					WelcomeImage1.TranslateTo (0, +57, 0, Easing.Linear);
					WelcomeImage2.TranslateTo (0, -20, 0, Easing.Linear);
					WelcomeImage3.TranslateTo (0, -97, 0, Easing.Linear);

					ModeButton7.TranslateTo (0, -225, 0, Easing.Linear);
					ModeButton6.TranslateTo (0, -300, 0, Easing.Linear);
					ModeButton5.TranslateTo (0, -380, 0, Easing.Linear);
					ModeButton4.TranslateTo (0, -445, 0, Easing.Linear);
					ModeButton3.TranslateTo (0, -510, 0, Easing.Linear);
					ModeButton2.TranslateTo (0, -575, 0, Easing.Linear);
					ModeButton1.TranslateTo (0, -640, 0, Easing.Linear);

					ModeButton1.FadeTo (0, 0, Easing.Linear);
					ModeButton2.FadeTo (0, 0, Easing.Linear);
					ModeButton3.FadeTo (0, 0, Easing.Linear);
					ModeButton4.FadeTo (0, 0, Easing.Linear);
					ModeButton5.FadeTo (0, 0, Easing.Linear);
					ModeButton6.FadeTo (0, 0, Easing.Linear);
					ModeButton7.FadeTo (0, 0, Easing.Linear);


					ModeButton1.Scale = 1.00;
					ModeButton2.Scale = 0.95;
					ModeButton3.Scale = 0.90;
					ModeButton4.Scale = 0.85;
					ModeButton5.Scale = 0.80;
					ModeButton6.Scale = 0.75;
					ModeButton7.Scale = 0.70;

					ModeButton1.RotationX = -5;
					ModeButton2.RotationX = -5;
					ModeButton3.RotationX = -5;
					ModeButton4.RotationX = -5;
					ModeButton5.RotationX = -5;
					ModeButton6.RotationX = -5;
					ModeButton7.RotationX = -5;

					
					//ModeButton1.RotationY = 360;
					//ModeButton2.RotationY = 355;
					//ModeButton3.RotationY = 350;
					//ModeButton4.RotationY = 345;
					//ModeButton5.RotationY = 340;
					//ModeButton6.RotationY = 335;
					//ModeButton7.RotationY = 330;
					//

				}
				else {
					WelcomeImage1.TranslateTo (0, +150, 0, Easing.Linear);
					WelcomeImage2.TranslateTo (0, +50, 0, Easing.Linear);
					WelcomeImage3.TranslateTo (0, -50, 0, Easing.Linear);


					ModeButton7.TranslateTo (0, -253, 0, Easing.Linear);
					ModeButton6.TranslateTo (0, -332, 0, Easing.Linear);
					ModeButton5.TranslateTo (0, -410, 0, Easing.Linear);
					ModeButton4.TranslateTo (0, -488, 0, Easing.Linear);
					ModeButton3.TranslateTo (0, -565, 0, Easing.Linear);
					ModeButton2.TranslateTo (0, -640, 0, Easing.Linear);
					ModeButton1.TranslateTo (0, -715, 0, Easing.Linear);


					ModeButton1.FadeTo (0, 0, Easing.Linear);
					ModeButton2.FadeTo (0, 0, Easing.Linear);
					ModeButton3.FadeTo (0, 0, Easing.Linear);
					ModeButton4.FadeTo (0, 0, Easing.Linear);
					ModeButton5.FadeTo (0, 0, Easing.Linear);
					ModeButton6.FadeTo (0, 0, Easing.Linear);
					ModeButton7.FadeTo (0, 0, Easing.Linear);
			

					ModeButton1.Scale = 1.00;
					ModeButton2.Scale = 0.95;
					ModeButton3.Scale = 0.90;
					ModeButton4.Scale = 0.85;
					ModeButton5.Scale = 0.80;
					ModeButton6.Scale = 0.75;
					ModeButton7.Scale = 0.70;

					ModeButton1.RotationX = -5;
					ModeButton2.RotationX = -5;
					ModeButton3.RotationX = -5;
					ModeButton4.RotationX = -5;
					ModeButton5.RotationX = -5;
					ModeButton6.RotationX = -5;
					ModeButton7.RotationX = -5;
				}

					
				AnimateHelpText = AsyncAnimateHelpTextOut ();
				AnimateHelpText = AsyncAnimateHelpTextIn ();
			}

			else
			{
				//this.BackgroundColor = Color.FromRgb (247, 247, 247);
				//this.BackgroundColor = Color.FromRgb (64, 64, 64);
				PayLabel.Opacity = 1;
				LineSeparator.Opacity = 1;
				//PayLabel.Text = "\n     ready for billing S$: 0.00";
				PayLabel.Text = "S$: 0.00";
				PaymentAmount = 0;

				StackLayout NumberPad = new StackLayout {
					Spacing = 0,
					Children = {
						//ButtonsSet4,
						ButtonsSet3,
						ButtonsSet2,
						ButtonsSet1,
						ButtonsSet0,
						//RewardsImage,
						//RecordAudioButton
					}
				};

				this.Content = new StackLayout {
					Spacing = Device.OnPlatform (10, 10, 10),
					Children = {
						PayLabel,
						LineSeparator,
						//PlaceHolderLabel,
						NumberPad
					}
				};
			}
	


			TestButton1.Clicked += TestButton1Clicked;		
			TestButton2.Clicked += TestButton2Clicked;
			TestButton3.Clicked += TestButton3Clicked;
			TestButton4.Clicked += TestButton4Clicked;
			TestButton5.Clicked += TestButton5Clicked;
			TestButton6.Clicked += TestButton6Clicked;
			TestButton7.Clicked += TestButton7Clicked;
			TestButton8.Clicked += TestButton8Clicked;
			TestButton9.Clicked += TestButton9Clicked;
			TestButton0.Clicked += TestButton0Clicked;
			/*
			TestButtonDot.Clicked += TestButtonDotClicked;
			TestButtonM.Clicked += TestButtonMClicked;
			TestButtonU.Clicked += TestButtonUClicked;
			TestButtonA.Clicked += TestButtonAClicked;
			TestButtonZ.Clicked += TestButtonZClicked;
			TestButton50.Clicked += TestButton50Clicked;	
			TestButton150.Clicked += TestButton150Clicked;	
			TestButton300.Clicked += TestButton300Clicked;
			*/
			TestButtonDel.Clicked += TestButtonDelClicked;
			TestButtonBill.Clicked += TestButtonBillClicked;
			RecordAudioButton.Clicked += RecordAudioButtonClicked;

		
			var tapGestureRecognizer = new TapGestureRecognizer();
				//tapGestureRecognizer.Tapped += async (s, e) => 
				//await Navigation.PushAsync(new TopUpPage());
			tapGestureRecognizer.Tapped += (s, e) => {

			    if (s.Equals(WelcomeImage1))
				{
					ShowHidePaymentModes();
				}
				else if (s.Equals(WelcomeImage2))
				{
					ShowHidePaymentModes();
				}
				else if (s.Equals(WelcomeImage3))
				{
					ShowHidePaymentModes();
				}

				else if (s.Equals(ScanningImage))
				{

					//while (true) {
					//	CountDown (1000);
					//	GetMerchantStatus = AsyncGetMerchantStatus("6594873518");
					//	if (MerchantStatus != "IDLE" || MerchantStatus != "ACTIVE")
					//	{
					//		ShowHidePaymentModes();
					//DisplayAlert ("Payment Confirmation", "S$XX.XX paid to Starbucks", "OK");
						//+MerchantStatus+" paid to Starbucks", "OK");
					//		ShowHidePaymentModes();
					//		UpdateMerchantStatus = AsyncUpdateMerchantStatus ("ACTIVE");
					//		break;
					//	}
					//}
				}

				else if (s.Equals(RewardsImage))
				{
					DisplayAlert ("", "Swipe right for merchant rewards", "OK");
					//DisplayAlert ("Enjoy more perks", "Swipe right for merchant rewards", "OK");
				}
				else 	
					if (!App.MerchantMode) {DisplayAlert ("pay using tebel", "Add payment mode to start", "OK");}
					else {DisplayAlert ("bill using tebel", "Add billing mode to start", "OK");}

			};

			//RewardsImage.GestureRecognizers.Add (tapGestureRecognizer);
			//this.Content.GestureRecognizers.Add (tapGestureRecognizer);
			WelcomeImage1.GestureRecognizers.Add (tapGestureRecognizer);
			WelcomeImage2.GestureRecognizers.Add (tapGestureRecognizer);
			WelcomeImage3.GestureRecognizers.Add (tapGestureRecognizer);
			ScanningImage.GestureRecognizers.Add (tapGestureRecognizer);

        }

		void ShowHidePaymentModes()	{
		    
			if (ModeButton1.Opacity == 1) {
				if (Device.OnPlatform (1, 2, 3) == 1) {
					ModeButton7.TranslateTo (0, -225, 500, Easing.CubicInOut);
					ModeButton6.TranslateTo (0, -300, 500, Easing.CubicInOut);
					ModeButton5.TranslateTo (0, -380, 500, Easing.CubicInOut);
					ModeButton4.TranslateTo (0, -445, 500, Easing.CubicInOut);
					ModeButton3.TranslateTo (0, -510, 500, Easing.CubicInOut);
					ModeButton2.TranslateTo (0, -575, 500, Easing.CubicInOut);
					ModeButton1.TranslateTo (0, -640, 500, Easing.CubicInOut);

					ModeButton1.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton2.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton3.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton4.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton5.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton6.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton7.FadeTo (0, 500, Easing.CubicInOut);
				}

				else {
					ModeButton7.TranslateTo (0, -253, 500, Easing.Linear);
					ModeButton6.TranslateTo (0, -332, 500, Easing.Linear);
					ModeButton5.TranslateTo (0, -410, 500, Easing.Linear);
					ModeButton4.TranslateTo (0, -488, 500, Easing.Linear);
					ModeButton3.TranslateTo (0, -565, 500, Easing.Linear);
					ModeButton2.TranslateTo (0, -640, 500, Easing.Linear);
					ModeButton1.TranslateTo (0, -715, 500, Easing.Linear);

					ModeButton1.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton2.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton3.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton4.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton5.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton6.FadeTo (0, 500, Easing.CubicInOut);
					ModeButton7.FadeTo (0, 500, Easing.CubicInOut);
				}

				/*CountDown (500);
				ModeButton1.IsVisible = false;
				ModeButton2.IsVisible = false;
				ModeButton3.IsVisible = false;
				ModeButton4.IsVisible = false;
				ModeButton5.IsVisible = false;
				ModeButton6.IsVisible = false;
				ModeButton7.IsVisible = false;
				*/

				//#if __IOS__
				//BTProgressHUD.Dismiss();
				//#endif
			}
			else {
				if (Device.OnPlatform (1, 2, 3) == 1) {
					ModeButton1.FadeTo (1, 0, Easing.Linear);
					ModeButton2.FadeTo (0.8, 0, Easing.Linear);
					ModeButton3.FadeTo (0.8, 0, Easing.Linear);
					ModeButton4.FadeTo (0.8, 0, Easing.Linear);
					ModeButton5.FadeTo (0.8, 0, Easing.Linear);
					ModeButton6.FadeTo (0.8, 0, Easing.Linear);
					ModeButton7.FadeTo (0.8, 0, Easing.Linear);

					ModeButton7.TranslateTo (0, -225, 500, Easing.CubicInOut);
					ModeButton6.TranslateTo (0, -335, 500, Easing.CubicInOut);
					ModeButton5.TranslateTo (0, -445, 500, Easing.CubicInOut);
					ModeButton4.TranslateTo (0, -555, 500, Easing.CubicInOut);
					ModeButton3.TranslateTo (0, -670, 500, Easing.CubicInOut);
					ModeButton2.TranslateTo (0, -790, 500, Easing.CubicInOut);
					ModeButton1.TranslateTo (0, -910, 500, Easing.CubicInOut);
				}
				else {
					ModeButton1.FadeTo (1, 0, Easing.Linear);
					ModeButton2.FadeTo (0.8, 0, Easing.Linear);
					ModeButton3.FadeTo (0.8, 0, Easing.Linear);
					ModeButton4.FadeTo (0.8, 0, Easing.Linear);
					ModeButton5.FadeTo (0.8, 0, Easing.Linear);
					ModeButton6.FadeTo (0.8, 0, Easing.Linear);
					ModeButton7.FadeTo (0.8, 0, Easing.Linear);

					ModeButton7.TranslateTo (0, -233, 500, Easing.CubicInOut);
					ModeButton6.TranslateTo (0, -370, 500, Easing.CubicInOut);
					ModeButton5.TranslateTo (0, -510, 500, Easing.CubicInOut);
					ModeButton4.TranslateTo (0, -655, 500, Easing.CubicInOut);
					ModeButton3.TranslateTo (0, -805, 500, Easing.CubicInOut);
					ModeButton2.TranslateTo (0, -958, 500, Easing.CubicInOut);
					ModeButton1.TranslateTo (0, -1115, 500, Easing.CubicInOut);
				}
				//#if __IOS__
				//BTProgressHUD.Show();
				//#endif
			}
	
		}

		void TestButton1Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.01;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton2Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.02;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton3Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.03;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton4Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.04;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton5Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.05;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton6Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.06;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton7Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.07;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton8Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.08;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton9Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10 + 0.09;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		void TestButton0Clicked(object sender, EventArgs e)	{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (PaymentAmount < 1000) PaymentAmount = PaymentAmount * 10;
			PayLabel.Text =  "S$: " + PaymentAmount.ToString("N");
			//this.Title = "S$" + PaymentAmount.ToString("N");
		}
		//void TestButtonDotClicked(object sender, EventArgs e)	{PayLabel.Text += '.';}
		void TestButtonDelClicked(object sender, EventArgs e)   {
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			PaymentAmount = 0;
			PayLabel.Text =  "S$: 0.00";
			//this.Title = "Starbucks CS";
		}

		/*
		void TestButton50Clicked(object sender, EventArgs e)
		{if (TestButton50.BackgroundColor == Color.FromRgb (0, 112, 192))
				TestButton50.BackgroundColor = Color.Gray;
			else {
				TestButton50.BackgroundColor = Color.FromRgb (0, 112, 192);
				TestButton150.BackgroundColor = Color.Gray;
				TestButton300.BackgroundColor = Color.Gray;
			}
		}
		void TestButton150Clicked(object sender, EventArgs e)
		{if (TestButton150.BackgroundColor == Color.FromRgb (0, 112, 192))
			TestButton150.BackgroundColor = Color.Gray;
		else {
			TestButton150.BackgroundColor = Color.FromRgb (0, 112, 192);
			TestButton50.BackgroundColor = Color.Gray;
			TestButton300.BackgroundColor = Color.Gray;
			}
		}
		void TestButton300Clicked(object sender, EventArgs e) 
		{if (TestButton300.BackgroundColor == Color.FromRgb (0, 112, 192))
			TestButton300.BackgroundColor = Color.Gray;
		else {
			TestButton300.BackgroundColor = Color.FromRgb (0, 112, 192);
			TestButton150.BackgroundColor = Color.Gray;
			TestButton50.BackgroundColor = Color.Gray;
			}
		}
		void TestButtonAClicked(object sender, EventArgs e)	{PayLabel.Text += 'A';}
		void TestButtonZClicked(object sender, EventArgs e)	{PayLabel.Text += 'Z';}
		void TestButtonMClicked(object sender, EventArgs e)	{PayLabel.Text += 'M';}
		void TestButtonUClicked(object sender, EventArgs e)	{PayLabel.Text += 'U';}
		*/

		void TestButtonBillClicked(object sender, EventArgs e)
		{
			Refractored.Xam.Vibrate.CrossVibrate.Current.Vibration(App.VibrationMS);
			if (TestButtonBill.Text != "X") {
				TestButtonBill.BackgroundColor = Color.FromRgb (51, 181, 229);//Color.FromRgb (2, 206, 194);//Color.FromRgb (250, 150, 50);
				TestButtonBill.Text = "X";
				RecordAudioButton.Text = "";

				//MerchantStatus = PayLabel.Text.Substring (4);
				//UpdateMerchantStatus = AsyncUpdateMerchantStatus (MerchantStatus);

				//while (true) {
					//CountDown (1000);
					//GetMerchantStatus = AsyncGetMerchantStatus ("6594873518");
					//if (MerchantStatus == "ACTIVE")
					//{
						DisplayAlert ("Bill Confirmation", "S$"+PayLabel.Text.Substring (4)+" received from customer", "OK");
						TestButtonBill.BackgroundColor = Color.FromRgb (0, 112, 192);
						TestButtonBill.Text = "Bill";
						PayLabel.Text =  "S$: 0.00";
						PaymentAmount = 0;
						//break;
					//}
				//}
				//PlayAudio (10000);

			}
			else {
				TestButtonBill.BackgroundColor = Color.FromRgb (0, 112, 192);
				TestButtonBill.Text = "Bill";
				PayLabel.Text =  "S$: 0.00";
				PaymentAmount = 0;
				UpdateMerchantStatus = AsyncUpdateMerchantStatus ("ACTIVE");
				//TestButton50.BackgroundColor = Color.Gray;
				//TestButton150.BackgroundColor = Color.Gray;
				//TestButton300.BackgroundColor = Color.Gray;
			}

		}

		/*
		void TestButton1Clicked(object sender, EventArgs e)	{PlayAudio(3000);}
		void TestButton2Clicked(object sender, EventArgs e)	{PlayAudio(4000);}
		void TestButton3Clicked(object sender, EventArgs e)	{PlayAudio(5000);}
		void TestButton4Clicked(object sender, EventArgs e)	{PlayAudio(6000);}
		void TestButton5Clicked(object sender, EventArgs e)	{PlayAudio(7000);}
		void TestButton6Clicked(object sender, EventArgs e)	{PlayAudio(8000);}
		void TestButton7Clicked(object sender, EventArgs e)	{PlayAudio(9000);}
		void TestButton8Clicked(object sender, EventArgs e)	{PlayAudio(10000);}
		*/


		/*
		async Task UpdatePhoneOrientation()
		{
			while (!PaymentInitiated) {			
				await Task.Delay (10);
				//PayLabel.Text = Tebel.Android.MainActivity.AndroidOrientationX + "\n" +
				//				Tebel.Android.MainActivity.AndroidOrientationY + "\n" +
				//				Tebel.Android.MainActivity.AndroidOrientationZ + "\n";
					
				ScanningImage.Scale = ((Tebel.Android.MainActivity.AndroidOrientationY) / 9.81);

				//ScanningImage.Rotation = 360;
				//await ScanningImage.RotateTo (0, 2250, Easing.Linear);
				//await 
				//	PayLabel.TranslateTo (-5 * ((Tebel.Android.MainActivity.AndroidOrientationX) / 2.5),
				//	5 * ((Tebel.Android.MainActivity.AndroidOrientationY - 6) / 2.5), 100, Easing.Linear);
				//	LineSeparator.TranslateTo (-5 * ((Tebel.Android.MainActivity.AndroidOrientationX) / 2.5),
				//	5 * ((Tebel.Android.MainActivity.AndroidOrientationY - 6) / 2.5), 100, Easing.Linear);
				
				//PayLabel.TranslationX = -10 * ((Tebel.Android.MainActivity.AndroidOrientationX) / 2.5);
				//PayLabel.TranslationY = 10 * ((Tebel.Android.MainActivity.AndroidOrientationY - 6) / 2.5);
				//ScanningImage.TranslationX = -10 * ((Tebel.Android.MainActivity.AndroidOrientationX) / 2.5);
				//ScanningImage.TranslationY = 10 * ((Tebel.Android.MainActivity.AndroidOrientationY - 6) / 2.5);
				//ScanningImage.RotationX = -5 + ((Tebel.Android.MainActivity.AndroidOrientationY - 6)/2.5) * 15;
				//ScanningImage.RotationY = ScanningImage.RotationY + ((Tebel.Android.MainActivity.AndroidOrientationX) / 2.5) * 15;
			}
		}
		*/

		async Task AsyncAnimateScanningImage()
		{
			while (!PaymentInitiated) {
				ScanningImage.Opacity = 0.15;
				await ScanningImage.FadeTo (0.85, 3000, Easing.CubicInOut);
				await ScanningImage.FadeTo (0.15, 1500, Easing.CubicInOut);
			}
		}

		async Task AsyncRotateScanningImage()
		{
			while (!PaymentInitiated) {
				ScanningImage.AnchorX = 0.50;
				ScanningImage.AnchorY = 0.65;
				ScanningImage.RotationY = 360;
				ScanningImage.RotationX = -5;
				await ScanningImage.RotateYTo (0, 2250, Easing.Linear);
			}
		}


		async Task AsyncAnimateHelpTextOut()
		{
			while (true) {
				await WelcomeImage3.FadeTo (0, 1000, Easing.CubicInOut);
				await WelcomeImage3.FadeTo (0, 3500, Easing.CubicInOut);

				await WelcomeImage1.FadeTo (0, 1000, Easing.CubicInOut);
				await WelcomeImage1.FadeTo (0, 3500, Easing.CubicInOut);

				await WelcomeImage2.FadeTo (0, 1000, Easing.CubicInOut);
				await WelcomeImage2.FadeTo (0, 3500, Easing.CubicInOut);
			}
		}

		async Task AsyncAnimateHelpTextIn()
		{
			while (true) {
				await WelcomeImage1.FadeTo (1, 1000, Easing.CubicInOut);
				await WelcomeImage1.FadeTo (1, 3500, Easing.CubicInOut);

				await WelcomeImage2.FadeTo (1, 1000, Easing.CubicInOut);
				await WelcomeImage2.FadeTo (1, 3500, Easing.CubicInOut);

				await WelcomeImage3.FadeTo (1, 1000, Easing.CubicInOut);
				await WelcomeImage3.FadeTo (1, 3500, Easing.CubicInOut);
			}
		}


		void CountDown(int MilliSeconds)
		{
			//await Task.Delay(MilliSeconds);
			System.Threading.Thread.Sleep(MilliSeconds);
		}




		void RecordAudioButtonClicked(object sender, EventArgs e)
		{
			if (Device.OnPlatform (1, 2, 3) == 1)
				IRecordAudio();
			else 
				ARecordAudio();
		}

		void PlayAudio(double frequency)
		{
			string TextMessage = (string) PayLabel.Text;
			//adding prefix and postfix character
			TextMessage = "A" + TextMessage + "Z";
			string MorseMessage = "";

			for (int i = 0; i < TextMessage.Length; i++)
			{
				char c = TextMessage[i];
				if (MorseCode.ContainsKey(c))
				{
					RecordAudioButton.Text+=(MorseCode[c]);
					RecordAudioButton.Text+="/";
				}
			}

			for(int i = 0; i < RecordAudioButton.Text.Length; i++)
			{
				char c = RecordAudioButton.Text[i];
				if (c == '.')
				{
					MorseMessage+="10";
				}
				else if (c == '-')
				{
					MorseMessage+="1110";
				}
				else if (c == '/')
				{
					MorseMessage+="000";
				}
			}

			if (Device.OnPlatform (1, 2, 3) == 1)
				IPlayAudio((float)frequency, MorseMessage);
			else 
				APlayAudio(frequency, MorseMessage);
		}


		void APlayAudio(double frequency, string OutputMorseMessage)
		{

			#if __ANDROID__
			/*
			double MessagePeriod = 10;
			int SamplePerPeriod = (int)((MessagePeriod / 1000) * 44100);

			byte[] AudioSamples = new byte[SampleSize];

			AudioTrack AudioTrack = new AudioTrack(
				global::Android.Media.Stream.Music, // Stream type
				44100, // Sampling Frequency
				ChannelOut.Mono, // Mono or stereo
				global::Android.Media.Encoding.Pcm8bit, // Audio encoding
				SampleSize, // Length of the audio clip
				AudioTrackMode.Static); // Mode. Stream or static);

			for(int i = 0; (i != SampleSize) && (OutputMorseMessage.Length > (int) i / SamplePerPeriod); i++)
			{
				if (OutputMorseMessage[(int) i / SamplePerPeriod] == '1')
				AudioSamples[i] = (byte)(127 * Math.Sin((double) i * 2.0 * Math.PI * frequency / 44100.0));
				else
				AudioSamples[i] = (byte)(0);
			}
			*/

						/*
						for(int i = 0; i != SampleSize/5; ++i)
						{
							AudioSamples[i] = (byte)(127 * Math.Sin((double) i * 2.0 * Math.PI * frequency / 44100.0));
						}

						for(int i = SampleSize/5; i != 2*SampleSize/5; ++i)
						{
							AudioSamples[i] = (byte)(127 * Math.Sin((double) i * 2.0 * Math.PI * 0.6 * frequency / 44100.0));
						}

						for(int i = 2*SampleSize/5; i != 3*SampleSize/5; ++i)
						{
							AudioSamples[i] = (byte)(127 * Math.Sin((double) i * 2.0 * Math.PI * frequency / 44100.0));
						}
			 
						for(int i = 3*SampleSize/5; i != 4*SampleSize/5; ++i)
						{
							AudioSamples[i] = (byte)(127 * Math.Sin((double) i * 2.0 * Math.PI * 0.6 * frequency / 44100.0));
						}

						for(int i = 4*SampleSize/5; i != SampleSize; ++i)
						{
							AudioSamples[i] = (byte)(127 * Math.Sin((double) i * 2.0 * Math.PI * 0.8 * frequency / 44100.0));
						}
						*/

			/*AudioTrack.Write(AudioSamples, 0, SampleSize);
			AudioTrack.ReloadStaticData();
			AudioTrack.SetLoopPoints (0, SampleSize - (int)(44100 % frequency), 1);
			AudioTrack.Play();
			//CountDown(1000);
			//AudioTrack.Stop();
			//AudioTrack.Release();
			*/
				/* Methods for AudioTrack
				AAudioTrack.Play();
				AAudioTrack.Write(AAudioBuffer, 0, AAudioBuffer.Length);
				AAudioTrack.Pause ();
				AAudioTrack.Stop ();
				AAudioTrack.Release ();
				*/

			#endif
		}


		unsafe void IPlayAudio(float outputFrequency, string OutputMorseMessage)
		{
	
			#if __IOS__

			double MessagePeriod = 10;
			//int SamplePerPeriod = (int)((MessagePeriod / 1000) * 44100);

			double sampleRate;
			const int numBuffers = 3;
			NSError AudioError;

			//
			// Setup audio system
			//
			var session = AVAudioSession.SharedInstance();
			session.SetCategory(new NSString("AVAudioSessionCategoryPlayback"), AVAudioSessionCategoryOptions.DefaultToSpeaker, out AudioError);

			//
			// Format description, we generate LinearPCM as short integers
			//
			sampleRate = session.SampleRate;
			var format = new AudioStreamBasicDescription
			{
				SampleRate = sampleRate,
				Format = AudioFormatType.LinearPCM,
				FormatFlags = AudioFormatFlags.LinearPCMIsSignedInteger | AudioFormatFlags.LinearPCMIsPacked,
				BitsPerChannel = 16,
				ChannelsPerFrame = 1,
				BytesPerFrame = 2,
				BytesPerPacket = 2,
				FramesPerPacket = 1,
			};

			//
			// Create an output queue
			//
			var queue = new OutputAudioQueue(format);
			var bufferByteSize = (sampleRate > 16000) ? 2176 : 512; // 40.5 Hz : 31.25 Hz

			//
			// Create three buffers, generate a tone, and output the tones
			//
			var buffers = new AudioQueueBuffer* [numBuffers];
			for (int i = 0; i < numBuffers; i++)
			{
				queue.AllocateBuffer(bufferByteSize, out buffers[i]);

				///
				// Make the buffer length a multiple of the wavelength for the output frequency.
				uint sampleCount = buffers[i]->AudioDataBytesCapacity / 2;
				double bufferLength = sampleCount;
				double wavelength = sampleRate / outputFrequency;
				double repetitions = Math.Floor(bufferLength / wavelength);
				if (repetitions > 0)
					sampleCount = (uint)Math.Round(wavelength * repetitions);

				double x, y;
				double sd = 1.0 / sampleRate;
				double max16bit = Int16.MaxValue;
				int j;
				short* p = (short*)buffers[i]->AudioData;

				for (j = 0; j < sampleCount; j++)
				{
					x = j * sd * outputFrequency;
					y = Math.Sin(x * 2.0 * Math.PI);
					p[j] = (short)(y * max16bit);
				}

				buffers[i]->AudioDataByteSize = sampleCount * 2;

				queue.EnqueueBuffer(buffers[i], null);
			}

			//
			// Output callback: invoked when the audio system is done with the
			// buffer, this implementation merely recycles it.
			//
			queue.OutputCompleted += (object sender, OutputCompletedEventArgs e) =>
			{
				queue.EnqueueBuffer(e.UnsafeBuffer, null);
			};

			queue.Start();
			CountDown(1000);
			queue.Stop(true);
			queue.Dispose();

			#endif
	
		}

		void IRecordAudio()
		{
			//#if __IOS__
			/*
			AVAudioRecorder recorder;
			NSError AudioError = new NSError(new NSString("sg.com.wavepay"), 1);
			NSUrl url;
			NSDictionary settings;

			//Declare string for application temp path and tack on the file extension
			string fileName = "tebel.wav";
			string tmpdir = NSBundle.MainBundle.BundlePath + "/tmp/";
			string audioFilePath = tmpdir + fileName;

			Console.WriteLine("Audio File Path: " + audioFilePath);

			url = NSUrl.FromFilename(audioFilePath);
			//set up the NSObject Array of values that will be combined with the keys to make the NSDictionary
			NSObject[] values = new NSObject[]
			{
				NSNumber.FromFloat (44100.0f), //Sample Rate
				NSNumber.FromInt32 ((int)MonoTouch.AudioToolbox.AudioFormatType.LinearPCM), //AVFormat
				NSNumber.FromInt32 (2), //Channels
				NSNumber.FromInt32 (16), //PCMBitDepth
				NSNumber.FromBoolean (false), //IsBigEndianKey
				NSNumber.FromBoolean (false) //IsFloatKey
			};

			//Set up the NSObject Array of keys that will be combined with the values to make the NSDictionary
			NSObject[] keys = new NSObject[]
			{
				AVAudioSettings.AVSampleRateKey,
				AVAudioSettings.AVFormatIDKey,
				AVAudioSettings.AVNumberOfChannelsKey,
				AVAudioSettings.AVLinearPCMBitDepthKey,
				AVAudioSettings.AVLinearPCMIsBigEndianKey,
				AVAudioSettings.AVLinearPCMIsFloatKey
			};

			//Set Settings with the Values and Keys to create the NSDictionary
			settings = NSDictionary.FromObjectsAndKeys (values, keys);

			//Set recorder parameters
			recorder = AVAudioRecorder.ToUrl(url, settings, out AudioError);

			//Set Recorder to Prepare To Record
			recorder.PrepareToRecord();
			recorder.Record();
			CountDown(1000);
			recorder.Stop();
			recorder.Dispose();
			*/

			//#endif
		}

		void ARecordAudio()
		{
			#if __ANDROID__
			/*
			byte[] AudioBuffer = new byte[SampleSize * 2];

			var AudRecorder = new AudioRecord(
				AudioSource.Mic, // Hardware source of recording
				44100, // Frequency
				ChannelIn.Mono, // Mono or stereo
				global::Android.Media.Encoding.Pcm16bit, // Audio encoding
				SampleSize * 2 // Length of the audio clip
			);
				
			AudRecorder.StartRecording ();

			while (true)
			{
				try
				{
					// Keep reading the buffer while there is audio input
					AudRecorder.Read(AudioBuffer, 0, AudioBuffer.Length);

					AudRecorder.Stop();
					AudRecorder.Release();

					AudioTrack AudioTrack = new AudioTrack(
						global::Android.Media.Stream.Music, // Stream type
						44100, // Sampling Frequency
						ChannelOut.Mono, // Mono or stereo
						global::Android.Media.Encoding.Pcm16bit, // Audio encoding
						SampleSize * 2, // Length of the audio clip
						AudioTrackMode.Static // Mode. Stream or static
					);

					AudioTrack.Write(AudioBuffer, 0, SampleSize * 2);
					AudioTrack.ReloadStaticData();
					AudioTrack.SetLoopPoints (0, SampleSize, 1);
					AudioTrack.Play();
					CountDown(1000);
					AudioTrack.Stop();
					AudioTrack.Release();
			
					// Write out the audio file
				}
				catch (Exception ex)
				{
					Console.Out.WriteLine(ex.Message);
					break;
				}
			}
			*/
				
			#endif
		}


		async Task AsyncUpdateMerchantStatus(string merchantStatus)
		{
			// Create a request using a URL that can receive a post. 
			WebRequest request = WebRequest.Create ("https://tebel.sg/webservice/update_status.php");
			// Set the Method property of the request to POST.
			request.Method = "POST";

			//var postData = "MOBILE=6582012466";
			//postData += "&PIN="+OptionPIN.Value;
			string postData = "MOBILE=6594873518&STATUS=" + merchantStatus;
			//var data = Encoding.ASCII.GetBytes(postData);
		
			// Create POST data and convert it to a byte array.
			//string postData = "This is a test that posts this string to a Web server.";
			byte[] byteArray = Encoding.UTF8.GetBytes (postData);
			// Set the ContentType property of the WebRequest.
			request.ContentType = "application/x-www-form-urlencoded";
			// Set the ContentLength property of the WebRequest.
			request.ContentLength = byteArray.Length;

			// Get the request stream.
			Stream dataStream = await request.GetRequestStreamAsync ();//.Result;
			// Write the data to the request stream.
			await dataStream.WriteAsync (byteArray, 0, byteArray.Length);
			// Close the Stream object.
			dataStream.Close ();

			// Get the response.
			WebResponse response = await request.GetResponseAsync ();//.Result;
			// Display the status.
			Console.WriteLine (((HttpWebResponse)response).StatusDescription);
			// Get the stream containing content returned by the server.
			dataStream = response.GetResponseStream ();
			// Open the stream using a StreamReader for easy access.
			StreamReader reader = new StreamReader (dataStream);
			// Read the content.
			string responseFromServer = await reader.ReadToEndAsync ();//.Result;
			// Display the content.
			Console.WriteLine (responseFromServer);
			// Clean up the streams.
			reader.Close ();
			dataStream.Close ();
			response.Close ();
		}


		async Task AsyncGetMerchantStatus(string merchantLocation)
		{

			// Create a request for the URL. 
			WebRequest request = WebRequest.Create (
				"https://tebel.sg/webservice/get_user.php?MOBILE="+merchantLocation);
			// If required by the server, set the credentials.
			//request.Credentials = CredentialCache.DefaultCredentials;
			// Get the response.
			request.ContentType = "application/json";
			request.Method = "GET";

			WebResponse response = await request.GetResponseAsync ();// ().Result;
			// Display the status.
			//Console.WriteLine (((HttpWebResponse)response).StatusDescription);
			// Get the stream containing content returned by the server.
			Stream dataStream = response.GetResponseStream ();
			// Open the stream using a StreamReader for easy access.
			StreamReader reader = new StreamReader (dataStream);
			// Read the content.
			string responseFromServer = await reader.ReadToEndAsync ();//.Result;
			// Display the content.
			//Console.WriteLine (responseFromServer);

			var get_user = Newtonsoft.Json.Linq.JObject.Parse (responseFromServer);
			MerchantStatus = (string) get_user ["STATUS"];
			//DisplayAlert ("", (string)get_user ["PIN"], "OK");

			// Clean up the streams and the response.
			reader.Close ();
			response.Close ();

		}


		async Task AsyncCountDown(int MilliSeconds)
		{
			await Task.Delay(MilliSeconds);
			//System.Threading.Thread.Sleep(MilliSeconds);
		}

    }
}

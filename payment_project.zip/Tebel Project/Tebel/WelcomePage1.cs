﻿using System;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace Tebel
{ 
    class WelcomePage1 : ContentPage
	{
		//public Task UpdateOrientation = null;
				
		public WelcomePage1()
        {
			this.Title = "Welcome1";
			this.BackgroundColor = Color.White;
			this.BackgroundImage = "cafe.jpg";
			this.Padding = new Thickness(0, 0, 0, 0);

		 	Image WelcomeImage1 = new Image
			{
				Source = ImageSource.FromFile("Welcome1.png"),
				//WidthRequest = Device.OnPlatform(160,192,160),
				//HeightRequest = Device.OnPlatform(160,192,160),
				//WidthRequest = ParentView.Width,
				Opacity = 0.9,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};


			this.Content = WelcomeImage1; 
			//UpdateOrientation = UpdatePhoneOrientation ();
		}


		/*
		async Task UpdatePhoneOrientation()
		{
			while (true) {			
				await Task.Delay (30);
				await 
				WelcomeImage1.TranslateTo (-2 * ((Tebel.Android.MainActivity.AndroidOrientationX) / 2.5),
					2 * ((Tebel.Android.MainActivity.AndroidOrientationY - 6) / 2.5), 30, Easing.Linear);
			}
		}
		*/

    }
}

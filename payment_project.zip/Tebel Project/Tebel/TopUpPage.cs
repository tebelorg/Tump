﻿using System;
using Xamarin.Forms;

namespace Tebel
{
    class TopUpPage : ContentPage
    {
		public double TopUpAmount = 0;


		public Button TopUpButton = new Button {
			IsVisible = false,
			Text = Device.OnPlatform("","Available top-up amounts",""),
			FontSize = 18,
			//FontAttributes = FontAttributes.Bold,
			IsEnabled = false,
			TextColor = Color.Gray,
			BackgroundColor = Color.Transparent,
			//TextColor = Device.OnPlatform(Color.White,Color.White,Color.White),
			//BackgroundColor = Color.White,
			BorderWidth = 1,
			BorderColor = Color.Transparent,
			//HeightRequest = 80,
			HorizontalOptions = LayoutOptions.Center,
			VerticalOptions = LayoutOptions.Center
		};

		public TopUpPage()
        {
			this.Title = Device.OnPlatform ("Top-up", "   Top-up", "");
			this.BackgroundColor = Color.White;
			this.Padding = new Thickness(0, 0, 0, 0);
			//this.Padding = new Thickness(10, 0, 10, 0);

			Label TopUpLabel = new Label {
				Text = "\n     Choose preferred amount",
				FontSize = 18,
				TextColor = Color.Gray,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};

			BoxView LineSeparator = new BoxView {
				Color = Color.Accent,
				HeightRequest = 2,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center
			};

			Button TopUpButton1 = new Button {
				Text = "S$50",
				//Font = Font.SystemFontOfSize (50, FontAttributes.Bold),
				FontSize = 50,
				BackgroundColor = Color.White,
				TextColor = Color.FromRgb (0, 112, 192),
				WidthRequest = 180,
				HeightRequest = 90,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
			TopUpButton1.Clicked +=  TopUpButton1Clicked;

			Button TopUpButton2 = new Button {
				Text = "S$150",
				//Font = Font.SystemFontOfSize (50, FontAttributes.Bold),
				FontSize = 50,
				BackgroundColor = Color.White,
				TextColor = Color.FromRgb (0, 112, 192),
				WidthRequest = 180,
				HeightRequest = 90,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
			TopUpButton2.Clicked +=  TopUpButton2Clicked;

			Button TopUpButton3 = new Button {
				Text = "S$300",
				//Font = Font.SystemFontOfSize (50, FontAttributes.Bold),
				FontSize = 50,
				BackgroundColor = Color.White,
				TextColor = Color.FromRgb (0, 112, 192),
				WidthRequest = 180,
				HeightRequest = 90,
				BorderWidth = 1,
				BorderColor = Color.Silver,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
			TopUpButton3.Clicked +=  TopUpButton3Clicked;

            this.Content = new StackLayout
            {
				Spacing = Device.OnPlatform(10, 25, 10),
                Children = 
                {
                    TopUpLabel,
					LineSeparator,
                    TopUpButton1,
					TopUpButton2,
					TopUpButton3,
					TopUpButton
                }
            };
        }

        void TopUpButton1Clicked(object sender, EventArgs e)
        {
			TopUpAmount = 50;
			DisplayAlert ("Top-up $50", "Verification in progress", "Cancel");
        }

		void TopUpButton2Clicked(object sender, EventArgs e)
		{
			TopUpAmount = 150;
			DisplayAlert ("Top-up $150", "Verification in progress", "Cancel");
		}

		void TopUpButton3Clicked(object sender, EventArgs e)
		{
			TopUpAmount = 300;
			DisplayAlert ("Top-up $300", "Verification in progress", "Cancel");
		}
			
    }
}

﻿using System;
using Xamarin.Forms;
using System.Collections.Generic;

using System.IO;
using SQLite;

namespace Tebel
{
    class ActivityPage : ContentPage
    {
		private class ActivityRecord {
			[PrimaryKey, AutoIncrement]
			public int ActivityNumber { get; set; }
			public Color Logo { get; set; }
			[MaxLength(1)]
			public string Initial { get; set; }
			[MaxLength(30)]
			public string Name { get; set; }
			[MaxLength(10)]
			public string Price { get; set; }
			public DateTime Date { get; set; }
		}

		class PaymentActivity
		{
			public PaymentActivity(Color logo, string initial, string name, string price, DateTime date)
			{
				this.Logo = logo;
				this.Initial = initial;
				this.Name = name;
				this.Price = price;
				this.Date = date;
			}

			public Color Logo { set; get; }
			public string Initial {  set; get; }
			public string Name {  set; get; }
			public string Price {  set; get; }
			public DateTime Date {  set; get; }

		};

		private static object DBLockerActivity = new object();
		private static string sqliteFilename = "LocalDB.db3";        
		#if __ANDROID__
		// Just use whatever directory SpecialFolder.Personal returns
		private static string libraryPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal); 
		#else
		// we need to put in /Library/ on iOS5.1 to meet Apple's iCloud terms
		// (they don't want non-user-generated data in Documents)
		private static string documentsPath = Environment.GetFolderPath (Environment.SpecialFolder.Personal); // Documents folder
		private static string libraryPath = Path.Combine (documentsPath, "..", "Library"); // Library folder instead
		#endif
		private static string DatabasePath = Path.Combine (libraryPath, sqliteFilename);
		private static SQLiteAsyncConnection LocalDBActivity = new SQLiteAsyncConnection (DatabasePath);
		private static ActivityRecord ActivityRecordTemp = new ActivityRecord ();
		//private static PaymentActivity PaymentActivityTemp = new PaymentActivity(Color.FromRgb(192,192,192), "S", "Ichiban Sushi Hougang", "S$35.20", new DateTime(2015, 1, 6)) ;

		public ActivityPage()
        { 
			this.Title = Device.OnPlatform ("Activity", " Activity", "");
			this.BackgroundColor = Color.White;
			this.Padding = new Thickness(10, Device.OnPlatform(5, 10, 0), Device.OnPlatform(5, 10, 0), 0);

			/*
			Label ActivityLabel = new Label {
				Text = "\n   View past payment activity",
				FontSize = 18,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};

			BoxView LineSeparator = new BoxView {
				Color = Color.Accent,
				HeightRequest = 2,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center
			};
			*/
			/*
			List<PaymentActivity> PaymentActivities = new List<PaymentActivity>{ };

			lock (DBLockerActivity) {
				LocalDBActivity.CreateTableAsync<ActivityRecord> ();
				if (LocalDBActivity.Table<ActivityRecord> ().CountAsync().Result == 0) {
					ActivityRecordTemp.Logo = Color.Gray;
					ActivityRecordTemp.Initial = "S";
					ActivityRecordTemp.Name = "Ichiban Sushi Hougang";
					ActivityRecordTemp.Price = "S$35.20";
					ActivityRecordTemp.Date = new DateTime (2015, 1, 6);
					LocalDBActivity.InsertAsync (ActivityRecordTemp);

					ActivityRecordTemp = new ActivityRecord ();
					ActivityRecordTemp.Logo = Color.Teal;
					ActivityRecordTemp.Initial = "C";
					ActivityRecordTemp.Name = "Caltex Kiosk Hougang";
					ActivityRecordTemp.Price = "S$43.10";
					ActivityRecordTemp.Date = new DateTime (2015, 1, 6);
					LocalDBActivity.InsertAsync (ActivityRecordTemp);

					ActivityRecordTemp = new ActivityRecord ();
					ActivityRecordTemp.Logo = Color.Navy;
					ActivityRecordTemp.Initial = "M";
					ActivityRecordTemp.Name = "Massimo Dutti Ngee Ann City";
					ActivityRecordTemp.Price = "S$89.90";
					ActivityRecordTemp.Date = new DateTime (2015, 1, 4);
					LocalDBActivity.InsertAsync (ActivityRecordTemp);
				}
*/
					/*
					else
					{
						var table = LocalDB.Table<ActivityRecord> ();
						foreach (ActivityRecord ar in table)
						{
							LocalDB.GetAsync<ActivityRecord> ().Result;
						}
					}
					*/
			
					
				/*
				var table = LocalDB.Table<ActivityRecord> ();

				ActivityRecord AR = table.ElementAtAsync (1).Result;


				foreach (IEnumerable<ActivityRecord> AR in table)
				{
					PaymentActivityTemp.Logo = AR.Logo;
					PaymentActivityTemp.Initial = AR.Initial;
					PaymentActivityTemp.Name = AR.Name;
					PaymentActivityTemp.Price = AR.Price;
					PaymentActivityTemp.Date = AR.Date;
					PaymentActivities.Add (PaymentActivityTemp);
				}

				*/

			//}

			// red = Color.FromRgb(250,100,150) //Color.FromRgb(222,57,117)
			// blue = Color.FromRgb(0,192,192)//Color.FromRgb(2,206,194)
			// purple = Color.FromRgb(192,50,192)//Color.FromRgb(192,0,192)
			// green = Color.FromRgb(150,192,0) //Color.FromRgb(173,198,8)
			// orange = Color.FromRgb(250,150,50)
			// yellow = Color.FromRgb(250,192,0) //Color.FromRgb(245,196,0)
			// gray = Color.FromRgb(192,192,192)

			// Define some data.

			
			List<PaymentActivity> PaymentActivities = new List<PaymentActivity>{
				new PaymentActivity(Color.FromRgb(192,192,192), "S", "Ichiban Sushi Hougang", "S$35.20", new DateTime(2015, 3, 6)),
				new PaymentActivity(Color.FromRgb(192,50,192), "C", "Caltex Kiosk Hougang", "S$43.10", new DateTime(2015, 3, 6)),
				new PaymentActivity(Color.FromRgb(0,192,192), "M", "Massimo Dutti Ngee Ann City", "S$89.90", new DateTime(2015, 3, 4)),
				new PaymentActivity(Color.FromRgb(250,100,150), "S", "SMRT Taxi", "S$15.20", new DateTime(2015, 2, 28)),
				new PaymentActivity(Color.FromRgb(150,192,0), "C", "Cold Storage NEX", "S$21.30", new DateTime(2015, 2, 27)),
				new PaymentActivity(Color.FromRgb(250,150,50), "G", "G2000 Anchorpoint", "S$15.20", new DateTime(2015, 2, 27)),
				new PaymentActivity(Color.FromRgb(0,192,192), "C", "Challenger Citysquare", "S$45.90", new DateTime(2015, 2, 26)),
				new PaymentActivity(Color.FromRgb(150,192,0), "C", "Cedele Wheelock Place", "S$62.50", new DateTime(2015, 2, 24)),
				new PaymentActivity(Color.FromRgb(250,100,150), "S", "Soup Restaurant", "S$40.72", new DateTime(2015, 2, 23)),
				new PaymentActivity(Color.FromRgb(250,100,150), "M", "Monster Curry NEX", "S$20.00", new DateTime(2015, 2, 21)),
				new PaymentActivity(Color.FromRgb(250,192,0), "C", "Charles & Keith Wisma", "S$59.90", new DateTime(2015, 2, 18)),
				new PaymentActivity(Color.FromRgb(192,192,192), "S", "Ichiban Sushi Hougang", "S$35.20", new DateTime(2014, 3, 6)),
				new PaymentActivity(Color.FromRgb(192,50,192), "C", "Caltex Kiosk Hougang", "S$43.10", new DateTime(2014, 3, 6)),
				new PaymentActivity(Color.FromRgb(0,192,192),"M", "Massimo Dutti Ngee Ann City", "S$89.90", new DateTime(2014, 3, 4)),
				new PaymentActivity(Color.FromRgb(250,100,150), "S", "SMRT Taxi", "S$15.20", new DateTime(2014, 2, 28)),
				new PaymentActivity(Color.FromRgb(150,192,0),"C", "Cold Storage NEX", "S$21.30", new DateTime(2014, 2, 27)),
				new PaymentActivity(Color.FromRgb(250,150,50), "G", "G2000 Anchorpoint", "S$15.20", new DateTime(2014, 2, 27)),
				new PaymentActivity(Color.FromRgb(0,192,192), "C", "Challenger Citysquare", "S$45.90", new DateTime(2014, 2, 26)),
				new PaymentActivity(Color.FromRgb(150,192,0), "C", "Cedele Wheelock Place", "S$62.50", new DateTime(2014, 2, 24)),
				new PaymentActivity(Color.FromRgb(250,100,150), "S", "Soup Restaurant", "S$40.72", new DateTime(2014, 2, 23)),
				new PaymentActivity(Color.FromRgb(250,100,150), "M", "Monster Curry NEX", "S$20.00", new DateTime(2014, 2, 21)),
				new PaymentActivity(Color.FromRgb(250,192,0), "C", "Charles & Keith Wisma", "S$59.90", new DateTime(2014, 2, 18)),
				new PaymentActivity(Color.FromRgb(192,192,192), "S", "Ichiban Sushi Hougang", "S$35.20", new DateTime(2013, 3, 6)),
				new PaymentActivity(Color.FromRgb(192,50,192), "C", "Caltex Kiosk Hougang", "S$43.10", new DateTime(2013, 3, 6)),
				new PaymentActivity(Color.FromRgb(0,192,192),"M", "Massimo Dutti Ngee Ann City", "S$89.90", new DateTime(2013, 3, 4)),
				new PaymentActivity(Color.FromRgb(250,100,150), "S", "SMRT Taxi", "S$15.20", new DateTime(2013, 2, 28)),
				new PaymentActivity(Color.FromRgb(150,192,0),"C", "Cold Storage NEX", "S$21.30", new DateTime(2013, 2, 27)),
				new PaymentActivity(Color.FromRgb(250,150,50), "G", "G2000 Anchorpoint", "S$15.20", new DateTime(2013, 2, 27)),
				new PaymentActivity(Color.FromRgb(0,192,192), "C", "Challenger Citysquare", "S$45.90", new DateTime(2013, 2, 26)),
				new PaymentActivity(Color.FromRgb(150,192,0), "C", "Cedele Wheelock Place", "S$62.50", new DateTime(2013, 2, 24)),
				new PaymentActivity(Color.FromRgb(250,100,150), "S", "Soup Restaurant", "S$40.72", new DateTime(2013, 2, 23)),
				new PaymentActivity(Color.FromRgb(250,100,150), "M", "Monster Curry NEX", "S$20.00", new DateTime(2013, 2, 21)),
				new PaymentActivity(Color.FromRgb(250,192,0), "C", "Charles & Keith Wisma", "S$59.90", new DateTime(2013, 2, 18)),
			};
			
				
			ListView ActivityList = new ListView
			{
				ItemsSource = PaymentActivities,

				// Define template for displaying each item.
				// (Argument of DataTemplate constructor is called for 
				//      each item; it must return a Cell derivative.)
				ItemTemplate = new DataTemplate(() =>
					{
						// Create views with bindings for displaying each property.
						Label InitialLabel = new Label
						{
							FontSize = 18,
							FontAttributes = FontAttributes.Bold, 
							XAlign = TextAlignment.Center,
							YAlign = TextAlignment.Center,
							HeightRequest = 40,
							WidthRequest = 40,
							TextColor = Color.White,
							BackgroundColor = Color.FromRgb (0, 112, 192),
							Opacity = 1,
							HorizontalOptions = LayoutOptions.Center,
							VerticalOptions = LayoutOptions.Center
						};
						InitialLabel.SetBinding(Label.TextProperty, "Initial");
						InitialLabel.SetBinding(Label.BackgroundColorProperty, "Logo");

						Label NameLabel = new Label();
						NameLabel.SetBinding(Label.TextProperty, "Name");
						NameLabel.WidthRequest = 300;

						Label PriceLabel = new Label();
						PriceLabel.SetBinding(Label.TextProperty, "Price");
						PriceLabel.WidthRequest = 108;

						Label DateLabel = new Label();
						DateLabel.SetBinding(Label.TextProperty,
							new Binding("Date", BindingMode.OneWay, 
								null, null, "{0:MMM d}"));
						DateLabel.WidthRequest = 108;

						/*Image ItemIcon = new Image
						{
							Source = ImageSource.FromFile("rewards.png"),
						};
						*/

						// Return an assembled ViewCell.
						return new ViewCell
						{
							View = new StackLayout
							{
								Padding = new Thickness(0, 5, 0, 5),
								Orientation = StackOrientation.Horizontal,
								VerticalOptions = LayoutOptions.Center,
								Children = 
								{
									InitialLabel,
									//ItemIcon,
									NameLabel,
									new StackLayout
									{
										VerticalOptions = LayoutOptions.Center,
										Spacing = 0,
										Children = 
										{
											PriceLabel,
											DateLabel
										}
									}


								}
							}
						};
					})
			};

			ActivityList.ItemSelected += ActivityListItemSelected;

			Picker ActivityCategory = new Picker {
				Title = "Category/Age",
				WidthRequest = Device.OnPlatform (149, 170, 170),
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			if (!App.MerchantMode) {
				//ActivityCategory.Title = "Category";
				ActivityCategory.Title = "";
				ActivityCategory.Items.Add ("Transport");
				ActivityCategory.Items.Add ("Supermarket");
				ActivityCategory.Items.Add ("Food & Beverage");
				ActivityCategory.Items.Add ("All Categories");
				ActivityCategory.Items.Add ("Shopping");
				ActivityCategory.Items.Add ("Others");
				//ActivityCategory.Items.Add ("TOP-UP");
				ActivityCategory.SelectedIndex = 3;
			}
			else {
				//ActivityCategory.Title = "Age Group";
				ActivityCategory.Title = "";
				ActivityCategory.Items.Add ("Ages 10 to 20");
				ActivityCategory.Items.Add ("Ages 20 to 30");
				ActivityCategory.Items.Add ("Ages 30 to 40");
				ActivityCategory.Items.Add ("Ages 40 to 50");
				ActivityCategory.Items.Add ("Ages 50 to 60+");
				ActivityCategory.SelectedIndex = 1;
			}

			Picker ActivityPeriod = new Picker
			{
				//Title = "Period",
				Title = "",
				WidthRequest = Device.OnPlatform (145, 165, 165),
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
			ActivityPeriod.Items.Add ("Today");
			ActivityPeriod.Items.Add ("All Months");
			ActivityPeriod.Items.Add ("March");
			ActivityPeriod.Items.Add ("February");
			ActivityPeriod.Items.Add ("January");
			ActivityPeriod.Items.Add ("December");
			ActivityPeriod.Items.Add ("November");
			ActivityPeriod.Items.Add ("October");

			if (App.MerchantMode)
				ActivityPeriod.SelectedIndex = 0;
			else
				ActivityPeriod.SelectedIndex = 1;

			ActivityPeriod.SelectedIndexChanged += ActivityPeriodSelectedIndexChanged;
	
			Picker ActivityMode = new Picker
			{
				//Title = "Payment",
				Title = "",
				WidthRequest = Device.OnPlatform (149, 170, 170),
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			ActivityMode.Items.Add ("POSB Savings");
			ActivityMode.Items.Add ("Citibank Visa");
			ActivityMode.Items.Add ("Stanchart Master");
			ActivityMode.Items.Add ("HSBC Amex");
			ActivityMode.Items.Add ("EZ-Link");

			ActivityMode.SelectedIndex = 1;


		    Label TotalLabel = new Label {
				Text = " Total S$: 892.20",
				FontSize = 18,
				//TextColor = Color.FromRgb (0, 192, 192),
				TextColor = Color.FromRgb (51,181,229),
				//TextColor = Color.Gray,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};

			StackLayout ActivityOptions = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				Children = 
				{
					ActivityCategory,
					ActivityPeriod
				}
			};
					
			StackLayout ActivityModeStack = new StackLayout {
				Orientation = StackOrientation.Horizontal,
				Children = 
				{
					ActivityMode,
					TotalLabel
				}
			};

            this.Content = new StackLayout
            {
				Spacing = Device.OnPlatform(10, 10, 10),
                Children = 
                {
                    //ActivityLabel,
					//LineSeparator,
					ActivityOptions,
					ActivityModeStack,
					ActivityList
                }
            };
					
        }

		void ActivityPeriodSelectedIndexChanged(object sender, EventArgs e)
		{

		}

		void ActivityListItemSelected(object sender, EventArgs e)
		{

			DisplayAlert("","Delete this activity?", "OK", "Cancel");
			//DisplayAlert ("Activities are not stored on cloud. Delete this activity from phone?", "OK", "Cancel");
		}
			
    }
}

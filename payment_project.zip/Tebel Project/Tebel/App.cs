﻿using System;
using Xamarin.Forms;

namespace Tebel
{
	public class App : Application
	{
		public static bool MerchantMode; // { get; set; }
		public static int  VibrationMS;

		public App ()
		{
			App.MerchantMode = false;
			App.VibrationMS = 500;

			MainPage = new NavigationPage(new HomePage()) {
				BarBackgroundColor = Device.OnPlatform (Color.Default, Color.FromRgb (0, 112, 192), Color.Default),
				//BarBackgroundColor = Device.OnPlatform (Color.Default, Color.FromRgb (0, 192, 192), Color.Default)
				//BarBackgroundColor = Device.OnPlatform (Color.Default, Color.FromRgb (64, 64, 64), Color.Default),
				//BarBackgroundColor = Device.OnPlatform (Color.Default, Color.FromRgb (247,247,247), Color.Default),
			};
		}

		protected override void OnResume()
		{
			base.OnResume();
		}

		protected override void OnSleep()
		{
			base.OnSleep();
		}

		protected override void OnStart()
		{
			base.OnStart();
		}
	
	}
}





﻿using System;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace Tebel
{ 
    class LocationsPage : ContentPage
	{
		public Task AnimateLocationsProgressBar = null; 
		public ProgressBar LocationsProgressBar = 
			new ProgressBar {Progress = 0, BackgroundColor = Color.White};

		public LocationsPage()
        {
			this.Title = Device.OnPlatform ("Locations", "   Locations", "");
			this.BackgroundColor = Color.White;

			WebView LocationsWeb = new WebView {
				Source = new UrlWebViewSource {Url = "http://www.instagram.com/tebelsg/"},
				VerticalOptions = LayoutOptions.FillAndExpand,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				BackgroundColor = Color.White
			};
			this.Content = new StackLayout
			{
				Spacing = 0,
				Children = 
				{
					LocationsProgressBar,
					LocationsWeb,
				}
			};
			AnimateLocationsProgressBar = AsyncAnimateLocationsProgressBar();
		}

		async Task AsyncAnimateLocationsProgressBar()
		{
			await LocationsProgressBar.ProgressTo (1, 2100, Easing.Linear);
			//LocationsProgressBar.IsVisible = false;
		}
    }
}

﻿using System;
using Xamarin.Forms;

namespace Tebel
{ 
    class WelcomePage3 : ContentPage
	{

		public WelcomePage3()
        {
			this.Title = "Welcome3";
			this.BackgroundColor = Color.White;
			this.BackgroundImage = "merchants.jpg";
			this.Padding = new Thickness(0, 0, 0, 0);

			Image WelcomeImage3 = new Image
			{
				Source = ImageSource.FromFile("Welcome3.png"),
				//WidthRequest = Device.OnPlatform(160,192,160),
				//HeightRequest = Device.OnPlatform(160,192,160),
				//WidthRequest = ParentView.Width,
				Opacity = 0.9,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};
			this.Content = WelcomeImage3; 
		}
    }
}

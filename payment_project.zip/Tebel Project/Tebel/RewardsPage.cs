﻿using System;
using Xamarin.Forms;

namespace Tebel
{
    class RewardsPage : ContentPage
    {

		public RewardsPage()
        {
			this.Title = Device.OnPlatform ("Rewards", "   Rewards", "");
			this.BackgroundColor = Color.FromRgb (112, 112, 112);
			this.Padding = new Thickness(0, 0, 0, 0);
			//this.Padding = new Thickness(10, 0, 10, 0);

			Label TopUpLabel = new Label {
				Text = "\n     Redeem merchant rewards",
				FontSize = 18,
				TextColor = Color.White,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};

			BoxView LineSeparator = new BoxView {
				Color =  Color.FromRgb (51, 181, 229),
				HeightRequest = 2,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center
			};
					
			this.Content = new StackLayout
            {
				Spacing = Device.OnPlatform(10, 25, 10),
                Children = 
                {
                    TopUpLabel,
					LineSeparator
                }
            };
					
        }
			
    }
}

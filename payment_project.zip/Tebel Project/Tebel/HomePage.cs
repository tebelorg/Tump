﻿using System;
using Xamarin.Forms;

namespace Tebel
{
	class HomePage : CarouselPage
    {

        public HomePage()
		{
			//this.Title = Device.OnPlatform ("S$125.10", "   S$125.10", "S$125.10");
			this.Title = Device.OnPlatform ("POSB Savings", " POSB Savings", "POSB Savings");
			if (App.MerchantMode)
				this.Title = Device.OnPlatform ("Starbucks", " Starbucks", "Starbucks");
			this.Title = Device.OnPlatform ("Starbucks", " Starbucks", "Starbucks");
			//this.Title = "Starbucks";
			//this.Title = "";

			this.BackgroundColor = Color.White;
			/*
			 * 
			ToolbarItem LocationsToolbar = new ToolbarItem ();
			LocationsToolbar.Text = "Locations";
			LocationsToolbar.Icon = Device.OnPlatform("Locations@2x.png","Locations.png","");
			LocationsToolbar.Order = ToolbarItemOrder.Primary;
			ToolbarItems.Add(LocationsToolbar);
			LocationsToolbar.Clicked += async (sender, args) =>
				await Navigation.PushAsync(new LocationsPage());
			*/
 
			ToolbarItem OptionsToolbar = new ToolbarItem ();
			OptionsToolbar.Text = "Settings";
			OptionsToolbar.Icon = Device.OnPlatform ("Options@2x.png", "Options.png", "");
			OptionsToolbar.Order = ToolbarItemOrder.Primary;
			ToolbarItems.Add (OptionsToolbar);
			OptionsToolbar.Clicked += async (sender, args) => 
				await Navigation.PushAsync (new OptionsPage ());
		  	
			this.Children.Add(new PayPage ());

			//ContentPage RewardsPageObject = new RewardsPage ();
			//ContentPage PayPageObject = new PayPage ();
			//ContentPage WelcomePageObject4 = new WelcomePage4 ();

			//ContentPage WelcomePageObject1 = new WelcomePage1 ();
			//ContentPage WelcomePageObject2 = new WelcomePage2 ();
			//ContentPage WelcomePageObject3 = new WelcomePage3 ();


			//this.Children.Add (RewardsPageObject);
			//this.Children.Add (PayPageObject);
			//this.Children.Add (WelcomePageObject4);
			//this.CurrentPage = this.Children [0];
			//this.CurrentPage = this.Children [1];

			/*
			this.Children.Add (WelcomePageObject1);
			this.CurrentPage = this.Children [1];

			if (Device.OnPlatform (1, 2, 3) == 2) {
				WelcomePageObject1.Appearing += (s, e) => {
					this.Children.Add (WelcomePageObject2);
				};

				WelcomePageObject2.Appearing += (s, e) => {
					this.Children.Add (WelcomePageObject3);
				};

			}
			else
			{
				this.Children.Add (WelcomePageObject2);
				this.Children.Add (WelcomePageObject3);
			}
			*/

		}		
    }
}

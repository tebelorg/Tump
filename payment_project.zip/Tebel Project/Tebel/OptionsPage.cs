﻿using System;
using Xamarin.Forms;

using System.Threading.Tasks;
using System.IO;
using SQLite;
using System.Net;
using System.Text;

#if __ANDROID__
using AndroidHUD;
//AndHUD.Shared.Show(this, "Loading...", -1, MaskType.Clear, TimeSpan.FromSeconds(3));
//AndHUD.Shared.Dismiss(myActivity);
#endif

namespace Tebel
{ 
    class OptionsPage : ContentPage
	{			
		private class OptionRecord {
			[PrimaryKey, MaxLength(10)]
			public string Option { get; set; }
			[MaxLength(30)]
			public string Value { get; set; }
			public bool State { get; set; }
		}

		public Task GetUserDetails = null; 
		public Task UpdateUserDetails = null; 

		private static object DBLocker = new object();
		private static string sqliteFilename = "LocalDB.db3";        
		#if __ANDROID__
		// Just use whatever directory SpecialFolder.Personal returns
		private static string libraryPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal); 
		#else
		// we need to put in /Library/ on iOS5.1 to meet Apple's iCloud terms
		// (they don't want non-user-generated data in Documents)
		private static string documentsPath = Environment.GetFolderPath (Environment.SpecialFolder.Personal); // Documents folder
		private static string libraryPath = Path.Combine (documentsPath, "..", "Library"); // Library folder instead
		#endif
		private static string DatabasePath = Path.Combine (libraryPath, sqliteFilename);
		private static SQLiteAsyncConnection LocalDB = new SQLiteAsyncConnection (DatabasePath);
		private static OptionRecord OptionPIN = new OptionRecord ();
		private static OptionRecord OptionEMAIL = new OptionRecord ();
		private static OptionRecord OptionDATE = new OptionRecord ();
		private static OptionRecord OptionONETAP = new OptionRecord ();
		private static OptionRecord OptionAUTOSELECT = new OptionRecord ();
		private static OptionRecord OptionACTIVITY = new OptionRecord ();
		private static OptionRecord OptionREGNO = new OptionRecord ();

		private static EntryCell EntryPIN = new EntryCell {
			Label = Device.OnPlatform ("PIN            ", "PIN              ", ""),
			Text = OptionPIN.Value,
			Placeholder = "enter 4-digit number",
			Keyboard = Keyboard.Numeric
		};

		public OptionsPage()
		{
			this.Title = Device.OnPlatform ("Settings", " Settings", "");
			this.BackgroundColor = Color.White;

			lock (DBLocker) {
				LocalDB.CreateTableAsync<OptionRecord> ();
				if (LocalDB.Table<OptionRecord> ().CountAsync ().Result != 7) {
					OptionPIN.Option = "PIN";
					OptionPIN.Value = "";
					OptionPIN.State = true;

					OptionEMAIL.Option = "EMAIL";
					OptionEMAIL.Value = "";
					OptionEMAIL.State = true;

					OptionDATE.Option = "DATE";
					OptionDATE.Value = "";
					OptionDATE.State = true;

					OptionONETAP.Option = "ONETAP";
					OptionONETAP.Value = "";
					OptionONETAP.State = true;

					OptionAUTOSELECT.Option = "AUTOSELECT";
					OptionAUTOSELECT.Value = "";
					OptionAUTOSELECT.State = true;

					OptionACTIVITY.Option = "ACTIVITY";
					OptionACTIVITY.Value = "";
					OptionACTIVITY.State = true;

					OptionREGNO.Option = "REGNO";
					OptionREGNO.Value = "";
					OptionREGNO.State = true;

					LocalDB.InsertAsync (OptionPIN);
					LocalDB.InsertAsync (OptionEMAIL);
					LocalDB.InsertAsync (OptionDATE);
					LocalDB.InsertAsync (OptionONETAP);
					LocalDB.InsertAsync (OptionAUTOSELECT);
					LocalDB.InsertAsync (OptionACTIVITY);
					LocalDB.InsertAsync (OptionREGNO);
				}
				else {
					OptionEMAIL = LocalDB.GetAsync<OptionRecord> ("EMAIL").Result;
					OptionDATE = LocalDB.GetAsync<OptionRecord> ("DATE").Result;
					OptionONETAP = LocalDB.GetAsync<OptionRecord> ("ONETAP").Result;
					OptionAUTOSELECT = LocalDB.GetAsync<OptionRecord> ("AUTOSELECT").Result;
					OptionACTIVITY = LocalDB.GetAsync<OptionRecord> ("ACTIVITY").Result;
					OptionREGNO = LocalDB.GetAsync<OptionRecord> ("REGNO").Result;
					OptionPIN = LocalDB.GetAsync<OptionRecord> ("PIN").Result;
					GetUserDetails = AsyncGetUserDetails ();
				
				}
			}

			Button PaymentModeButton = new Button {
				Text = "Mode Button",
				FontSize = 18,
				IsEnabled = true,
				FontAttributes = FontAttributes.Bold,
				//BackgroundColor = Color.FromRgb(0,192,192), //Color.FromRgb(0,192,192),//Color.FromRgb(250,150,50),
				BackgroundColor = Color.FromRgb (51,181,229),
				TextColor = Color.White, //Color.White,
				//TextColor = Color.FromRgb (0, 112, 192),
				WidthRequest = Device.OnPlatform (300, 320, 320),
				HeightRequest = Device.OnPlatform (50, 60, 60),
				BorderWidth = 1,
				BorderColor = Color.FromRgb(51,181,229),//Color.Silver,
				HorizontalOptions = LayoutOptions.Center,
				VerticalOptions = LayoutOptions.Center
			};
			if (!App.MerchantMode) PaymentModeButton.Text = "Add Payment Mode"; else PaymentModeButton.Text = "Add Billing Mode";

			/*
			ToolbarItem PaymentToolbar = new ToolbarItem ();
			if (!App.MerchantMode) PaymentToolbar.Text = "Add Payment Mode"; else PaymentToolbar.Text = "Add Billing Mode";
			PaymentToolbar.Icon = Device.OnPlatform("Cross@2x.png","Cross.png","");
			PaymentToolbar.Order = ToolbarItemOrder.Primary;
			ToolbarItems.Add(PaymentToolbar);
			PaymentToolbar.Clicked += async (sender, args) =>
				await Navigation.PushAsync(new ActivityPage());
			*/

			ToolbarItem ActivityToolbar = new ToolbarItem ();
			ActivityToolbar.Text = "Activity";
			ActivityToolbar.Icon = Device.OnPlatform("Activity@2x.png","Activity.png","");
			ActivityToolbar.Order = ToolbarItemOrder.Primary;
			ToolbarItems.Add(ActivityToolbar);
			ActivityToolbar.Clicked += async (sender, args) => 
				await Navigation.PushAsync (new ActivityPage ());

			this.Padding = new Thickness (
				Device.OnPlatform (0, 20, 0), 10,
				Device.OnPlatform (0, 20, 0),
				Device.OnPlatform (0, 0, 0));

			//PaymentModeButton.Clicked += async (sender, args) =>
			//	await Navigation.PushAsync(new ActivityPage());

			PaymentModeButton.Clicked += PaymentModeButtonClicked;

			/*
			EntryCell EntryPIN = new EntryCell {
				Label = Device.OnPlatform ("PIN            ", "PIN              ", ""),
				Text = OptionPIN.Value,
				Placeholder = "enter 4-digit number",
				Keyboard = Keyboard.Numeric
			};
			EntryPIN.BindingContext = OptionPIN;
			EntryPIN.SetBinding (EntryCell.TextProperty, "Value");
			*/

			EntryPIN.BindingContext = OptionPIN;
			EntryPIN.SetBinding (EntryCell.TextProperty, "Value");

			EntryCell EntryEMAIL = new EntryCell {
				//Label = "Name           ",
				Label = Device.OnPlatform ("Email         ", "Email          ", ""),
				Text = OptionEMAIL.Value,
				Placeholder = "email address",
				Keyboard = Keyboard.Text
			};
			EntryEMAIL.BindingContext = OptionEMAIL;
			EntryEMAIL.SetBinding (EntryCell.TextProperty, "Value");

			EntryCell EntryDATE = new EntryCell {
				Label = "Birthdate   ",
				Text = OptionDATE.Value,
				Placeholder = "DD/MM/YY",
				Keyboard = Keyboard.Text
			};
			EntryDATE.BindingContext = OptionDATE;
			EntryDATE.SetBinding (EntryCell.TextProperty, "Value");

			EntryCell EntryREGNO = new EntryCell {
				Label = "Reg No.      ",
				Text = OptionREGNO.Value,
				Placeholder = "ACRA reg no.",
				Keyboard = Keyboard.Text
			};
			EntryREGNO.BindingContext = OptionREGNO;
			EntryREGNO.SetBinding (EntryCell.TextProperty, "Value");

			SwitchCell SwitchONETAP = new SwitchCell {
				Text = "Smart-PIN",
				On = OptionONETAP.State
			};
			SwitchONETAP.BindingContext = OptionONETAP;
			SwitchONETAP.SetBinding (SwitchCell.OnProperty, "State");

			SwitchCell SwitchAUTOSELECT = new SwitchCell {
				Text = "Smart-Pay",
				On = OptionAUTOSELECT.State							
			};
			SwitchAUTOSELECT.BindingContext = OptionAUTOSELECT;
			SwitchAUTOSELECT.SetBinding (SwitchCell.OnProperty, "State");

			SwitchCell SwitchACTIVITY = new SwitchCell {
				Text = "Activity-Log",
				On = OptionACTIVITY.State
			};
			SwitchACTIVITY.BindingContext = OptionACTIVITY;
			SwitchACTIVITY.SetBinding (SwitchCell.OnProperty, "State");

			this.Content = 
				new StackLayout {
				Spacing = Device.OnPlatform(10, 10, 10),
				Children = {
				PaymentModeButton,
				new TableView {
				Intent = TableIntent.Form,
				Root = new TableRoot ("Settings") {

							new TableSection ("OPTIONS"){
								//new TextCell {
								//	Detail = "Make payment by tapping once to launch app",
								//},
								SwitchONETAP,

								//new TextCell {
								//	Detail = "Enable automatic selection of payment mode",
								//},
								SwitchAUTOSELECT,


								//new TextCell {
								//	Detail = "Save payment activity history on the phone",
								//},
								SwitchACTIVITY

								/*
						new TextCell {
							Detail = "Enable automatic-credit of rewards points",
						},
						new SwitchCell {
							Text = "T-REWARDS",
							On = true
						},
						
						new TextCell {
							Detail = "Receive promotions from favourite merchants",
						},
						new SwitchCell {
							Text = "PROMOTIONS",
							On = true	
						},
						*/

							},


					new TableSection ("SECURITY"){
					//new TextCell {
					//	Detail = "Protect against unauthorised account access",
					//},
					
					EntryPIN,
					EntryEMAIL,
					EntryDATE

					/*
					new EntryCell {
						Label = "Email            ",
						//Placeholder = "email address",
						Keyboard = Keyboard.Text
					},
					new EntryCell {
						Label = "Handphone ",
						//Placeholder = "handphone #",
						Keyboard = Keyboard.Numeric
					},
					*/
					
					/*
					new EntryCell {
						Label = "Q       ",
						Placeholder = "enter a security question",
						Keyboard = Keyboard.Chat
					},
					new EntryCell {
						Label = "A       ",
						Placeholder = "enter your security answer",
						Keyboard = Keyboard.Chat
					}
					*/

					},



							new TableSection ("PAYMENT") {
								//new TextCell {
								//	Detail = "Payment modes showing account last 4 digits",
								//},

								new TextCell {
									Text = "Citibank Visa (3432)",
									TextColor = Color.Black,
								},
								new TextCell {
									Text = "Stanchart Master (4827)",
									TextColor = Color.Black
								},
								new TextCell {
									Text = "OCBC Visa (1438)",
									TextColor = Color.Black
								},
								new TextCell {
									Text = "POSB Savings (8486)",
									TextColor = Color.Black
								},
								new TextCell {
									Text = "EZ-Link (1209)",
									TextColor = Color.Black
								}

							}
				}
			}
				}
			};


			if (App.MerchantMode) {
				this.Content = 
				new StackLayout {
				Children = {
				PaymentModeButton,
				new TableView {
					Intent = TableIntent.Form,
					Root = new TableRoot ("Settings") {

						new TableSection ("SECURITY") {
							//new TextCell {
							//	Detail = "Protect against unauthorised account access",
							//},

							EntryPIN,
							EntryEMAIL,
							EntryREGNO

							/*
					new EntryCell {
						Label = "Email            ",
						//Placeholder = "email address",
						Keyboard = Keyboard.Text
					},
					new EntryCell {
						Label = "Handphone ",
						//Placeholder = "handphone #",
						Keyboard = Keyboard.Numeric
					},
					*/

							/*
						new EntryCell {
							Label = "Q       ",
							Placeholder = "enter a security question",
							Keyboard = Keyboard.Chat
						},
						new EntryCell {
							Label = "A       ",
							Placeholder = "enter your security answer",
							Keyboard = Keyboard.Chat
						}9
						*/

						},


						new TableSection ("BILLLING") {
							//new TextCell {
							//	Detail = "Billing modes showing account last 4 digits",
							//},
								
							new TextCell {
								Text = "Citibank Visa (3432)",
								TextColor = Color.Black
							},

							new TextCell {
								Text = "Stanchart Master (4827)",
								TextColor = Color.Black
							},
							new TextCell {
								Text = "POSB Savings (8486)",
								TextColor = Color.Black
							}

						}


					}
				}
				}
				};
			}

        }

		void PaymentModeButtonClicked(object sender, EventArgs e)	{
		/*
			// Create a request for the URL. 
			WebRequest request = WebRequest.Create (
				"http://tebel.sg/webservice/get_user.php?MOBILE=6582012466");
			// If required by the server, set the credentials.
			//request.Credentials = CredentialCache.DefaultCredentials;
			// Get the response.
			request.ContentType = "application/json";
			request.Method = "GET";
	
			WebResponse response = request.GetResponse ();
			// Display the status.
			//Console.WriteLine (((HttpWebResponse)response).StatusDescription);
			// Get the stream containing content returned by the server.
			Stream dataStream = response.GetResponseStream ();
			// Open the stream using a StreamReader for easy access.
			StreamReader reader = new StreamReader (dataStream);
			// Read the content.
			string responseFromServer = reader.ReadToEnd ();
			// Display the content.
			//Console.WriteLine (responseFromServer);

			var get_user = Newtonsoft.Json.Linq.JObject.Parse (responseFromServer);
			//DisplayAlert ("", (string)get_user ["PIN"], "OK");

			OptionPIN.Value = (string)get_user ["PIN"];
			// Clean up the streams and the response.
			reader.Close ();
			response.Close ();
			*/



			/*
			var request = HttpWebRequest.Create("http://tebel.sg/webservice/get_user.php?MOBILE=6582012466");
			request.ContentType = "application/json";
			request.Method = "GET";


			using (HttpWebResponse response = request.GetResponse () as HttpWebResponse)
 				{			//HttpWebResponse response = (HttpWebResponse)request.GetResponse ();
				if (response.StatusCode != HttpStatusCode.OK)
					Console.Out.WriteLine ("Error fetching data. Server returned status code: {0}", response.StatusCode);

				using (StreamReader reader = new StreamReader (response.GetResponseStream ())) {
					var content = reader.ReadToEnd ();
					if (string.IsNullOrWhiteSpace (content)) {
						Console.Out.WriteLine ("Response contained empty body...");
					} else {
						//Console.Out.WriteLine("Response Body: \r\n {0}", content);
						var get_user = Newtonsoft.Json.Linq.JObject.Parse (response.CharacterSet);
						DisplayAlert ("", (string)get_user ["PIN"], "OK");
					}
				}
			}
			*/

		}

		async Task AsyncGetUserDetails()
		{
			EntryPIN.Placeholder = "loading...";

			// Create a request for the URL. 
			WebRequest request = WebRequest.Create (
				"https://tebel.sg/webservice/get_user.php?MOBILE=6582012466");
			// If required by the server, set the credentials.
			//request.Credentials = CredentialCache.DefaultCredentials;
			// Get the response.
			request.ContentType = "application/json";
			request.Method = "GET";

			WebResponse response = await request.GetResponseAsync ();// ().Result;
			// Display the status.
			//Console.WriteLine (((HttpWebResponse)response).StatusDescription);
			// Get the stream containing content returned by the server.
			Stream dataStream = response.GetResponseStream ();
			// Open the stream using a StreamReader for easy access.
			StreamReader reader = new StreamReader (dataStream);
			// Read the content.
			string responseFromServer = await reader.ReadToEndAsync ();//.Result;
			// Display the content.
			//Console.WriteLine (responseFromServer);

			var get_user = Newtonsoft.Json.Linq.JObject.Parse (responseFromServer);
			//DisplayAlert ("", (string)get_user ["PIN"], "OK");

			OptionPIN.Value = (string)get_user ["PIN"];
			// Clean up the streams and the response.
			reader.Close ();
			response.Close ();

			EntryPIN.Text = OptionPIN.Value;
			EntryPIN.Placeholder = "enter 4-digit number";
		}

		async Task AsyncUpdateUserDetails()
		{
			// Create a request using a URL that can receive a post. 
			WebRequest request = WebRequest.Create ("https://tebel.sg/webservice/update_user.php");
			// Set the Method property of the request to POST.
			request.Method = "POST";
			 
			//var postData = "MOBILE=6582012466";
			//postData += "&PIN="+OptionPIN.Value;
			string postData = "MOBILE=6582012466&PIN="+OptionPIN.Value;
			//var data = Encoding.ASCII.GetBytes(postData);

			// Create POST data and convert it to a byte array.
			//string postData = "This is a test that posts this string to a Web server.";
			byte[] byteArray = Encoding.UTF8.GetBytes (postData);
			// Set the ContentType property of the WebRequest.
			request.ContentType = "application/x-www-form-urlencoded";
			// Set the ContentLength property of the WebRequest.
			request.ContentLength = byteArray.Length;

			// Get the request stream.
			Stream dataStream = await request.GetRequestStreamAsync ();//.Result;
			// Write the data to the request stream.
			await dataStream.WriteAsync (byteArray, 0, byteArray.Length);
			// Close the Stream object.
			dataStream.Close ();

			// Get the response.
			WebResponse response = await request.GetResponseAsync ();//.Result;
			// Display the status.
			Console.WriteLine (((HttpWebResponse)response).StatusDescription);
			// Get the stream containing content returned by the server.
			dataStream = response.GetResponseStream ();
			// Open the stream using a StreamReader for easy access.
			StreamReader reader = new StreamReader (dataStream);
			// Read the content.
			string responseFromServer = await reader.ReadToEndAsync ();//.Result;
			// Display the content.
			Console.WriteLine (responseFromServer);
			// Clean up the streams.
			reader.Close ();
			dataStream.Close ();
			response.Close ();
		}

		protected override void OnDisappearing() {
			lock (DBLocker) {
		
				UpdateUserDetails = AsyncUpdateUserDetails ();
				OptionPIN.Option = "PIN";
				OptionPIN.Value = "";
				OptionPIN.State = true;
				LocalDB.UpdateAsync (OptionPIN);
				LocalDB.UpdateAsync (OptionEMAIL);
				LocalDB.UpdateAsync (OptionDATE);
				LocalDB.UpdateAsync (OptionONETAP);
				LocalDB.UpdateAsync (OptionAUTOSELECT);
				LocalDB.UpdateAsync (OptionREGNO);
				LocalDB.UpdateAsync (OptionACTIVITY);
			}
		}

	}
}

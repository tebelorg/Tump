﻿using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Tebel
{ 
    class WelcomePage4 : ContentPage
	{
		public Task AnimateHelpText = null;

		Image WelcomeImage3 = new Image
		{
			Source = ImageSource.FromFile("Welcome3.png"),
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			Opacity = 0.9,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		Image WelcomeImage1 = new Image
		{
			Source = ImageSource.FromFile("Welcome1.png"),
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			Opacity = 0,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};


		Image WelcomeImage2 = new Image
		{
			Source = ImageSource.FromFile("Welcome2.png"),
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			Opacity = 0,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		Image WelcomeImage4 = new Image
		{
			Source = ImageSource.FromFile("Welcome4.png"),
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			Opacity = 0,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		Image WelcomeImage5 = new Image
		{
			Source = ImageSource.FromFile("Welcome5.png"),
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			Opacity = 0,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};

		Image WelcomeImage6 = new Image
		{
			Source = ImageSource.FromFile("Welcome6.png"),
			//WidthRequest = Device.OnPlatform(160,192,160),
			//HeightRequest = Device.OnPlatform(160,192,160),
			//WidthRequest = ParentView.Width,
			Opacity = 0,
			HorizontalOptions = LayoutOptions.Start,
			VerticalOptions = LayoutOptions.Start
		};
				
		public WelcomePage4()
        {
		
			this.Title = "Welcome";
			this.BackgroundColor = Color.White;
			this.BackgroundImage = "merchant.jpg";
			this.Padding = new Thickness(0, 0, 0, 0);

			Label LocationsLabel = new Label {
				Text = "\n     ",
				FontSize = 18,
				TextColor = Color.White,
				HorizontalOptions = LayoutOptions.Start,
				VerticalOptions = LayoutOptions.Start
			};

			BoxView LineSeparator = new BoxView {
				Color =  Color.FromRgb (51, 181, 229),
				HeightRequest = 2,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center
			};
					
			this.Content = new StackLayout
			{
				Spacing = Device.OnPlatform(10, 25, 10),
				Children = 
				{
					LocationsLabel,
					LineSeparator,
					WelcomeImage3,
					WelcomeImage1,
					WelcomeImage2,
					WelcomeImage4,
					WelcomeImage5,
					WelcomeImage6
				}
			};

			if (Device.OnPlatform (1, 2, 3) == 1) {
				WelcomeImage3.TranslateTo (0, -57, 0, Easing.Linear);
				WelcomeImage1.TranslateTo (0, -134, 0, Easing.Linear);
				WelcomeImage2.TranslateTo (0, -211, 0, Easing.Linear);
				WelcomeImage4.TranslateTo (0, -288, 0, Easing.Linear);
				WelcomeImage5.TranslateTo (0, -365, 0, Easing.Linear);
				WelcomeImage6.TranslateTo (0, -442, 0, Easing.Linear);
			}
			else {
				WelcomeImage3.TranslateTo (0, -100, 0, Easing.Linear);
				WelcomeImage1.TranslateTo (0, -200, 0, Easing.Linear);
				WelcomeImage2.TranslateTo (0, -300, 0, Easing.Linear);
				WelcomeImage4.TranslateTo (0, -400, 0, Easing.Linear);
				WelcomeImage5.TranslateTo (0, -500, 0, Easing.Linear);
				WelcomeImage6.TranslateTo (0, -600, 0, Easing.Linear);
			}

			AnimateHelpText = AsyncAnimateHelpTextOut ();
			AnimateHelpText = AsyncAnimateHelpTextIn ();
		}

		async Task AsyncAnimateHelpTextOut()
		{
			while (true) {
				await WelcomeImage3.FadeTo (0, 1000, Easing.Linear);
				await WelcomeImage3.FadeTo (0, 3500, Easing.Linear);
				await WelcomeImage1.FadeTo (0, 1000, Easing.Linear);
				await WelcomeImage1.FadeTo (0, 3500, Easing.Linear);
				await WelcomeImage2.FadeTo (0, 1000, Easing.Linear);
				await WelcomeImage2.FadeTo (0, 3500, Easing.Linear);
				await WelcomeImage4.FadeTo (0, 1000, Easing.Linear);
				await WelcomeImage4.FadeTo (0, 3500, Easing.Linear);
				await WelcomeImage5.FadeTo (0, 1000, Easing.Linear);
				await WelcomeImage5.FadeTo (0, 3500, Easing.Linear);
				await WelcomeImage6.FadeTo (0, 1000, Easing.Linear);
				await WelcomeImage6.FadeTo (0, 3500, Easing.Linear);
			}
		}

		async Task AsyncAnimateHelpTextIn()
		{
			while (true) {
				await WelcomeImage1.FadeTo (0.9, 1000, Easing.Linear);
				await WelcomeImage1.FadeTo (0.9, 3500, Easing.Linear);
				await WelcomeImage2.FadeTo (0.9, 1000, Easing.Linear);
				await WelcomeImage2.FadeTo (0.9, 3500, Easing.Linear);
				await WelcomeImage4.FadeTo (0.9, 1000, Easing.Linear);
				await WelcomeImage4.FadeTo (0.9, 3500, Easing.Linear);
				await WelcomeImage5.FadeTo (0.9, 1000, Easing.Linear);
				await WelcomeImage5.FadeTo (0.9, 3500, Easing.Linear);
				await WelcomeImage6.FadeTo (0.9, 1000, Easing.Linear);
				await WelcomeImage6.FadeTo (0.9, 3500, Easing.Linear);
				await WelcomeImage3.FadeTo (0.9, 1000, Easing.Linear);
				await WelcomeImage3.FadeTo (0.9, 3500, Easing.Linear);
			}
		}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
//using BigTed;

using MonoTouch.Foundation;
using MonoTouch.UIKit;

using Xamarin.Forms;

namespace Tebel.iOS
{
	[Register ("AppDelegate")]
	public partial class AppDelegate : global::Xamarin.Forms.Platform.iOS.FormsApplicationDelegate  

	{
		//UIWindow window;

		public override bool FinishedLaunching (UIApplication app, NSDictionary options)
		{
			Forms.Init ();
			LoadApplication (new App ());  // method is new in 1.3
			/*window = new UIWindow (UIScreen.MainScreen.Bounds);
			window.RootViewController = App.GetMainPage ().CreateViewController ();
			window.MakeKeyAndVisible ();
			*/

			/*
			UINavigationBar.Appearance.TintColor = UIColor.White;
			UINavigationBar.Appearance.SetTitleTextAttributes(new UITextAttributes {TextColor = UIColor.White});
			*/

			UINavigationBar.Appearance.BarTintColor = UIColor.FromRGB (247, 247, 247);
			return base.FinishedLaunching (app, options);
		}
	}
}

